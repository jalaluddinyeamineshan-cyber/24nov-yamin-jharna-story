import React from 'react';
import {useCurrentFrame} from 'remotion';
import {C, fontFamily} from './config';

const ink = C.ink;
const R: React.FC<{x: number; y: number; w: number; h: number; f: string; r?: number; sw?: number; o?: number}> = ({x, y, w, h, f, r = 0, sw = 3, o = 1}) => (
  <rect x={x} y={y} width={w} height={h} rx={r} fill={f} stroke={ink} strokeWidth={sw} opacity={o} />
);
const Svg = ({children}: {children: React.ReactNode}) => (
  <svg viewBox="0 0 1920 1080" width="100%" height="100%" style={{position: 'absolute', left: 0, top: 0, fontFamily}}>{children}</svg>
);
const stars = Array.from({length: 46}, (_, i) => [(i * 977) % 1920, (i * 523) % 520, 1.5 + (i % 3)]);

// =============== ঘর: রান্নাঘর (বামে) + বসার ঘর (ডানে) ===============
export const Home: React.FC<{mood: 'night' | 'evening' | 'cozy'; pulse?: number; children?: React.ReactNode}> = ({mood, pulse = 0, children}) => {
  const fr = useCurrentFrame();
  const eve = mood === 'evening';
  const sky = eve ? 'url(#skyE)' : 'url(#skyN)';
  const hr = ((eve ? 210 : 60) * Math.PI) / 180;
  const books = ['#D64545', '#2F6EA8', '#F2C94C', '#4CAF7A', '#8E5AB5', '#F2994A'];
  const lampOn = mood !== 'evening';
  return (
    <Svg>
      <defs>
        <linearGradient id="skyN" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#0A1236" /><stop offset="1" stopColor="#233468" /></linearGradient>
        <linearGradient id="skyE" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#F4C27A" /><stop offset="1" stopColor="#EE7F5B" /></linearGradient>
        <pattern id="tile" width="60" height="60" patternUnits="userSpaceOnUse"><rect width="60" height="60" fill="#EAF3EE" /><path d="M0 0H60V60" fill="none" stroke="#B8CFC4" strokeWidth="3" /></pattern>
        <pattern id="plank" width="240" height="46" patternUnits="userSpaceOnUse"><rect width="240" height="46" fill="#BE9062" /><path d="M0 0H240M120 0V46" stroke="#9C7348" strokeWidth="3" fill="none" /></pattern>
        <pattern id="chk" width="80" height="80" patternUnits="userSpaceOnUse"><rect width="80" height="80" fill="#DCD6C8" /><rect width="40" height="40" fill="#C9C2B0" /><rect x="40" y="40" width="40" height="40" fill="#C9C2B0" /></pattern>
        <radialGradient id="glowW"><stop offset="0" stopColor="#FFE9A8" stopOpacity=".9" /><stop offset="1" stopColor="#FFE9A8" stopOpacity="0" /></radialGradient>
        <radialGradient id="nightG" cx="470" cy="110" r="1250" gradientUnits="userSpaceOnUse"><stop offset="0" stopColor="#FFC870" stopOpacity=".05" /><stop offset=".35" stopColor="#0A1030" stopOpacity=".4" /><stop offset="1" stopColor="#050818" stopOpacity=".78" /></radialGradient>
        <radialGradient id="cozyG" cx="960" cy="540" r="1200" gradientUnits="userSpaceOnUse"><stop offset=".45" stopColor="#FFB15C" stopOpacity="0" /><stop offset="1" stopColor="#40200A" stopOpacity=".5" /></radialGradient>
      </defs>

      {/* দেয়াল ও মেঝে */}
      <rect width="880" height="780" fill="#CFE6DC" />
      <rect x="880" width="1040" height="780" fill="#F0DEC4" />
      <rect x="880" y="690" width="1040" height="90" fill="#DFC9A3" />
      <rect y="780" width="880" height="300" fill="url(#chk)" />
      <rect x="880" y="780" width="1040" height="300" fill="url(#plank)" />
      <rect y="772" width="1920" height="14" fill="#7A6450" />
      <R x={868} y={0} w={26} h={780} f="#D8C4A4" />

      {/* ---------- রান্নাঘর ---------- */}
      <rect x="270" y="380" width="530" height="240" fill="url(#tile)" />
      {/* ফ্রিজ */}
      <R x={40} y={300} w={190} h={480} f="#C5D8E6" r={14} />
      <line x1={40} x2={230} y1={470} y2={470} stroke={ink} strokeWidth={3} />
      <R x={196} y={340} w={12} h={80} f="#9AAABB" r={5} /><R x={196} y={500} w={12} h={120} f="#9AAABB" r={5} />
      <R x={80} y={340} w={62} h={72} f="#FFF3A8" /><circle cx={165} cy={360} r={11} fill="#D64545" stroke={ink} strokeWidth={2} /><circle cx={160} cy={540} r={11} fill="#2F6EA8" stroke={ink} strokeWidth={2} />
      {/* ঘড়ি */}
      <circle cx={135} cy={170} r={54} fill="#fff" stroke={ink} strokeWidth={5} />
      {[0, 90, 180, 270].map((a) => <line key={a} x1={135} y1={125} x2={135} y2={134} stroke={ink} strokeWidth={4} transform={`rotate(${a} 135 170)`} />)}
      <line x1={135} y1={170} x2={135 + 28 * Math.sin(hr)} y2={170 - 28 * Math.cos(hr)} stroke={ink} strokeWidth={6} strokeLinecap="round" />
      <line x1={135} y1={170} x2={135} y2={130} stroke={ink} strokeWidth={4} strokeLinecap="round" />
      {/* জানালা */}
      <R x={330} y={150} w={250} h={190} f={sky} />
      {!eve && stars.slice(0, 8).map((s, i) => <circle key={i} cx={340 + ((s[0] * 3) % 230)} cy={160 + ((s[1] * 2) % 100)} r={2.5} fill="#fff" />)}
      {eve ? <circle cx={450} cy={300} r={42} fill="#FFE3A0" /> : <circle cx={500} cy={215} r={22} fill="#FFF6D6" />}
      <rect x={330} y={150} width={250} height={190} fill="none" stroke="#8A6A4C" strokeWidth={12} />
      <line x1={455} x2={455} y1={150} y2={340} stroke="#8A6A4C" strokeWidth={8} /><line x1={330} x2={580} y1={245} y2={245} stroke="#8A6A4C" strokeWidth={8} />
      {/* ঝুলন্ত বাসন + তাক */}
      <line x1={630} x2={860} y1={170} y2={170} stroke={ink} strokeWidth={6} />
      {[660, 720, 780, 830].map((x, i) => <g key={x}><line x1={x} x2={x} y1={170} y2={200} stroke={ink} strokeWidth={4} /><ellipse cx={x} cy={236} rx={i % 2 ? 14 : 24} ry={36} fill={i % 2 ? '#B7BFC7' : '#C9971A'} stroke={ink} strokeWidth={3} /></g>)}
      <R x={630} y={330} w={230} h={14} f="#8B5E3C" />
      {['#D64545', '#F2C94C', '#4CAF7A', '#fff'].map((c, i) => <R key={i} x={642 + i * 54} y={284} w={42} h={46} f={c} r={8} />)}
      <R x={630} y={430} w={230} h={14} f="#8B5E3C" />
      {['#F2994A', '#8E5AB5', '#2F6EA8'].map((c, i) => <R key={i} x={650 + i * 66} y={382} w={50} h={48} f={c} r={8} />)}
      {/* কাউন্টার */}
      <R x={270} y={644} w={520} h={136} f="#9A7552" />
      {[0, 1, 2].map((i) => <g key={i}><R x={282 + i * 170} y={656} w={160} h={112} f="#A98259" r={4} sw={2.5} /><circle cx={420 + i * 170} cy={712} r={6} fill="#444" /></g>)}
      <R x={262} y={620} w={536} h={26} f="#6E5A4A" r={4} />
      <R x={410} y={590} w={240} h={32} f="#444" r={4} />
      {[470, 590].map((x) => <g key={x}><ellipse cx={x} cy={588} rx={38} ry={9} fill="#222" stroke={ink} strokeWidth={3} /><ellipse cx={x} cy={588} rx={20} ry={4} fill="#666" /></g>)}
      <R x={282} y={598} w={86} h={24} f="#B7BFC7" r={6} /><path d="M326 598 v-34 q0 -14 20 -14" fill="none" stroke={ink} strokeWidth={8} /><path d="M326 598 v-34 q0 -14 20 -14" fill="none" stroke="#B7BFC7" strokeWidth={4} />
      <R x={690} y={560} w={50} h={60} f="#F2C94C" r={8} /><R x={744} y={574} w={44} h={46} f="#D64545" r={8} />
      <R x={380} y={602} w={22} h={18} f="#7BC47F" r={4} />

      {/* ---------- বসার ঘর ---------- */}
      {/* জানালা + পর্দা */}
      <R x={960} y={150} w={300} h={400} f={sky} />
      {!eve && stars.slice(8, 20).map((s, i) => <circle key={i} cx={970 + ((s[0] * 7) % 280)} cy={160 + ((s[1] * 3) % 280)} r={2.5} fill="#fff" />)}
      {eve ? <circle cx={1110} cy={450} r={62} fill="#FFE3A0" /> : <circle cx={1170} cy={250} r={30} fill="#FFF6D6" />}
      <rect x={960} y={150} width={300} height={400} fill="none" stroke="#8A6A4C" strokeWidth={14} />
      <line x1={1110} x2={1110} y1={150} y2={550} stroke="#8A6A4C" strokeWidth={8} />
      <line x1={920} x2={1300} y1={130} y2={130} stroke="#7A5C3C" strokeWidth={10} strokeLinecap="round" />
      <path d="M930 134 H1030 V560 Q990 540 930 560 Z" fill="#E9A6B4" stroke={ink} strokeWidth={3} /><path d="M1190 134 H1290 V560 Q1250 540 1190 560 Z" fill="#E9A6B4" stroke={ink} strokeWidth={3} />
      {[960, 990, 1220, 1250].map((x) => <line key={x} x1={x} x2={x} y1={140} y2={540} stroke="#C97C90" strokeWidth={3} />)}
      {/* ব্ল্যাকবোর্ড (ঝর্ণা পড়ায়) */}
      <R x={1330} y={150} w={310} h={220} f="#6B4A2B" r={8} /><R x={1344} y={164} w={282} h={192} f="#2D4B3E" />
      <text x={1485} y={245} textAnchor="middle" fontSize={62} fontWeight={700} fill="#fff">ক খ গ</text>
      <text x={1485} y={325} textAnchor="middle" fontSize={62} fontWeight={700} fill="#FFE08A">১ ২ ৩</text>
      <R x={1340} y={370} w={290} h={12} f="#8B5E3C" /><R x={1360} y={360} w={34} h={10} f="#fff" sw={2} />
      {/* ফ্রেম */}
      <R x={1690} y={170} w={110} h={140} f="#FFF" /><circle cx={1745} cy={225} r={26} fill="#C98F63" stroke={ink} strokeWidth={2.5} /><path d="M1710 300 Q1745 250 1780 300 Z" fill="#2F6EA8" stroke={ink} strokeWidth={2.5} />
      <R x={1690} y={340} w={110} h={120} f="#FFF8E1" /><text x={1745} y={380} textAnchor="middle" fontSize={26} fontWeight={700} fill="#D64545">নভেম্বর</text>
      {Array.from({length: 15}).map((_, i) => <circle key={i} cx={1712 + (i % 5) * 19} cy={402 + Math.floor(i / 5) * 18} r={4} fill="#9AA5B1" />)}
      {/* বইয়ের তাক */}
      <R x={1800} y={250} w={120} h={540} f="#A67C52" />
      {[0, 1, 2, 3].map((r) => (
        <g key={r}>
          <line x1={1800} x2={1920} y1={330 + r * 110} y2={330 + r * 110} stroke={ink} strokeWidth={5} />
          {Array.from({length: 4}).map((_, i) => <R key={i} x={1812 + i * 26} y={290 + r * 110 + (i % 2) * 8} w={22} h={40 - (i % 2) * 8} f={books[(i + r * 2) % 6]} sw={2} />)}
        </g>
      ))}
      {/* সোফা */}
      <R x={1270} y={520} w={500} h={170} f="#7C9CB5" r={40} />
      <R x={1250} y={620} w={540} h={130} f="#8FAEC6" r={30} />
      <R x={1230} y={590} w={70} h={190} f="#6C8CA6" r={28} /><R x={1750} y={590} w={70} h={190} f="#6C8CA6" r={28} />
      <R x={1260} y={776} w={26} h={20} f="#5A4636" /><R x={1760} y={776} w={26} h={20} f="#5A4636" />
      <R x={1330} y={560} w={110} h={100} f="#E3B65B" r={22} /><R x={1630} y={560} w={110} h={100} f="#C86B5B" r={22} />
      {/* স্ট্যান্ড ল্যাম্প */}
      <line x1={1055} x2={1055} y1={430} y2={790} stroke={ink} strokeWidth={8} /><ellipse cx={1055} cy={792} rx={40} ry={9} fill="#555" stroke={ink} strokeWidth={3} />
      <path d="M1015 440 L1095 440 L1080 380 L1030 380 Z" fill="#FFE3A0" stroke={ink} strokeWidth={3} />
      {/* গাছ */}
      <path d="M925 700 Q880 640 905 580 Q930 640 925 700 M930 700 Q960 630 1010 610 Q980 680 930 700 M925 700 Q900 620 940 560 Q960 640 930 700" fill="#4CAF7A" stroke={ink} strokeWidth={3} />
      <R x={900} y={700} w={62} h={76} f="#C86B5B" r={8} />
      {/* পাটি */}
      <ellipse cx={1250} cy={935} rx={360} ry={96} fill="#B9574B" stroke={ink} strokeWidth={3} />
      <ellipse cx={1250} cy={935} rx={322} ry={78} fill="none" stroke="#E7C58F" strokeWidth={8} />
      <ellipse cx={1250} cy={935} rx={250} ry={58} fill="none" stroke="#E7C58F" strokeWidth={4} strokeDasharray="14 12" />
      {/* পড়ার নিচু টেবিল */}
      <R x={1560} y={860} w={240} h={22} f="#8B5E3C" /><R x={1576} y={882} w={14} h={50} f="#6B4A2B" /><R x={1770} y={882} w={14} h={50} f="#6B4A2B" />
      <R x={1590} y={822} w={60} h={38} f="#D64545" sw={2.5} /><R x={1600} y={796} w={50} h={28} f="#2F6EA8" sw={2.5} /><R x={1700} y={826} w={34} h={36} f="#F2C94C" r={6} sw={2.5} />
      {[1708, 1718, 1728].map((x, i) => <line key={x} x1={x} x2={x + (i - 1) * 4} y1={826} y2={800} stroke={['#D64545', '#2F6EA8', '#4CAF7A'][i]} strokeWidth={5} strokeLinecap="round" />)}

      {/* ঝুলন্ত বাতি (রান্নাঘর) */}
      <line x1={470} x2={470} y1={0} y2={84} stroke={ink} strokeWidth={4} />
      <path d="M440 100 L500 100 L488 70 L452 70 Z" fill="#4A4F5A" stroke={ink} strokeWidth={3} />
      <circle cx={470} cy={106} r={20} fill={lampOn ? '#FFF1B0' : '#ddd'} stroke={ink} strokeWidth={3} />

      {/* চলমান উপাদান (ক্যারেক্টার/প্রপস) */}
      {children}

      {/* চালের ড্রাম — সামনের স্তর */}
      <g>
        <R x={800} y={600} w={112} h={200} f="#3E7CB1" r={12} /><R x={794} y={590} w={124} h={26} f="#2F5F8C" r={10} />
        <R x={816} y={660} w={80} h={80} f="#FFF3D0" r={8} /><text x={856} y={715} textAnchor="middle" fontSize={44} fontWeight={700} fill={ink}>চাল</text>
      </g>

      {/* আলো/সময়ের ওভারলে */}
      {mood === 'night' && <rect width="1920" height="1080" fill="url(#nightG)" />}
      {mood === 'evening' && <rect width="1920" height="1080" fill="#FF8A3D" opacity={0.16} />}
      {mood === 'cozy' && <><rect width="1920" height="1080" fill="url(#cozyG)" /><rect width="1920" height="1080" fill="#FFB15C" opacity={0.08} /></>}
      {lampOn && <circle cx={470} cy={106} r={230 + pulse * 70 + Math.sin(fr / 10) * 8} fill="url(#glowW)" opacity={0.45 + pulse * 0.4} />}
      {mood === 'cozy' && <circle cx={1055} cy={420} r={260} fill="url(#glowW)" opacity={0.35} />}
    </Svg>
  );
};

// =============== সিঁড়ির landing ===============
export const Landing: React.FC<{door: number; children?: React.ReactNode}> = ({door, children}) => {
  const fr = useCurrentFrame();
  const leaf = 292 * (1 - 0.82 * door);
  return (
    <Svg>
      <defs>
        <radialGradient id="bulbG"><stop offset="0" stopColor="#FFE79A" stopOpacity=".85" /><stop offset="1" stopColor="#FFE79A" stopOpacity="0" /></radialGradient>
        <radialGradient id="landV" cx="960" cy="300" r="1250" gradientUnits="userSpaceOnUse"><stop offset=".2" stopColor="#050818" stopOpacity="0" /><stop offset="1" stopColor="#050818" stopOpacity=".72" /></radialGradient>
        <pattern id="ftile" width="120" height="70" patternUnits="userSpaceOnUse"><rect width="120" height="70" fill="#75797F" /><path d="M0 0H120M0 0V70" stroke="#5E6168" strokeWidth="3" fill="none" /></pattern>
      </defs>
      <rect width="1920" height="800" fill="#B8BFCB" />
      <rect y="560" width="1920" height="240" fill="#8F98A8" /><line x1={0} x2={1920} y1={560} y2={560} stroke={ink} strokeWidth={3} />
      <rect y="800" width="1920" height="280" fill="url(#ftile)" /><rect y="794" width="1920" height="12" fill="#4F535A" />
      <rect x="130" width="26" height="800" fill="#6C7684" stroke={ink} strokeWidth={3} />
      <text x={640} y={470} textAnchor="middle" fontSize={230} fontWeight={700} fill="#8F98A8" opacity={0.7}>৩</text>
      <text x={640} y={540} textAnchor="middle" fontSize={54} fontWeight={700} fill="#8F98A8" opacity={0.8}>তলা</text>
      {/* জানালা + গ্রিল */}
      <R x={250} y={150} w={300} h={300} f="#0E1B3D" />
      {stars.slice(0, 10).map((s, i) => <circle key={i} cx={262 + ((s[0] * 5) % 276)} cy={162 + ((s[1] * 3) % 270)} r={2.5} fill="#fff" />)}
      <circle cx={470} cy={240} r={30} fill="#FFF6D6" />
      <rect x={250} y={150} width={300} height={300} fill="none" stroke="#4A4F5A" strokeWidth={14} />
      {[300, 350, 400, 450, 500].map((x) => <line key={x} x1={x} x2={x} y1={150} y2={450} stroke="#2B2F38" strokeWidth={7} />)}
      <line x1={250} x2={550} y1={300} y2={300} stroke="#2B2F38" strokeWidth={7} />
      {/* সিঁড়ি (বামে নিচে নামছে) */}
      {[1, 2, 3, 4].map((k) => <g key={k}><rect x={780 - 130 * k} y={800 + 62 * k} width={130} height={300} fill="#80848C" stroke={ink} strokeWidth={3} /><rect x={780 - 130 * k} y={800 + 62 * k} width={130} height={14} fill="#A5A9B2" /></g>)}
      <line x1={780} y1={640} x2={260} y2={888} stroke={ink} strokeWidth={14} strokeLinecap="round" /><line x1={780} y1={640} x2={260} y2={888} stroke="#B07A2C" strokeWidth={8} strokeLinecap="round" />
      {[0, 1, 2, 3].map((j) => <line key={j} x1={780 - 130 * j} x2={780 - 130 * j} y1={640 + (130 * j * 62) / 130} y2={800 + 62 * j} stroke={ink} strokeWidth={6} />)}
      {/* মিটার বক্স */}
      <R x={1620} y={200} w={190} h={250} f="#9AA5B1" r={6} /><R x={1642} y={224} w={146} h={80} f="#E6EBF0" /><circle cx={1715} cy={264} r={26} fill="#fff" stroke={ink} strokeWidth={3} /><line x1={1715} y1={264} x2={1730} y2={248} stroke={ink} strokeWidth={4} />
      {[0, 1, 2].map((i) => <circle key={i} cx={1670 + i * 46} cy={350} r={10} fill={['#D64545', '#F2C94C', '#4CAF7A'][i]} stroke={ink} strokeWidth={2} />)}
      {/* দরজা */}
      <R x={1180} y={220} w={320} h={580} f="#4A3220" />
      <rect x={1194} y={234} width={292} height={566} fill="#F9D98E" stroke={ink} strokeWidth={3} />
      <rect x={1194} y={234} width={292} height={566} fill="#FFF2C4" opacity={door * 0.9} />
      <R x={1340} y={560} w={120} h={140} f="#C9A27A" sw={2.5} o={door} /><R x={1220} y={440} w={80} h={360} f="#E9A6B4" sw={2.5} o={door} />
      <g><R x={1194} y={234} w={leaf} h={566} f="#7B4B2A" sw={4} /><R x={1194 + leaf * 0.12} y={270} w={leaf * 0.76} h={200} f="#8D5B36" sw={2.5} /><R x={1194 + leaf * 0.12} y={500} w={leaf * 0.76} h={260} f="#8D5B36" sw={2.5} /><circle cx={1194 + leaf - 24} cy={520} r={10} fill="#E8B923" stroke={ink} strokeWidth={2.5} /></g>
      <R x={1535} y={420} w={64} h={110} f="#E8B923" r={6} /><text x={1567} y={458} textAnchor="middle" fontSize={26} fontWeight={700} fill={ink}>৩-বি</text><text x={1567} y={500} textAnchor="middle" fontSize={22} fontWeight={700} fill={ink}>ইয়ামিন</text>
      <polygon points="1194,800 1486,800 1700,1040 1000,1040" fill="#FFE9A8" opacity={0.38 * door} />
      {/* জুতার র‍্যাক */}
      <R x={1590} y={640} w={290} h={160} f="#8B5E3C" /><line x1={1590} x2={1880} y1={720} y2={720} stroke={ink} strokeWidth={4} />
      <ellipse cx={1650} cy={702} rx={34} ry={13} fill="#161616" stroke={ink} strokeWidth={3} /><ellipse cx={1720} cy={702} rx={34} ry={13} fill="#161616" stroke={ink} strokeWidth={3} />
      <ellipse cx={1800} cy={702} rx={30} ry={12} fill="#9A8F85" stroke={ink} strokeWidth={3} /><ellipse cx={1850} cy={782} rx={20} ry={9} fill="#F2994A" stroke={ink} strokeWidth={3} /><ellipse cx={1660} cy={782} rx={34} ry={13} fill="#9A8F85" stroke={ink} strokeWidth={3} />
      {/* বাতি + পোকা */}
      <line x1={960} x2={960} y1={0} y2={92} stroke={ink} strokeWidth={4} />
      <circle cx={960} cy={120} r={380} fill="url(#bulbG)" opacity={0.5 + Math.sin(fr / 6) * 0.04} />
      <circle cx={960} cy={116} r={24} fill="#FFF1B0" stroke={ink} strokeWidth={3} />
      <circle cx={960 + Math.cos(fr / 7) * 60} cy={116 + Math.sin(fr / 5) * 40} r={4} fill="#333" />
      {children}
      <rect width="1920" height="1080" fill="url(#landV)" />
    </Svg>
  );
};

// =============== রাতের বিল্ডিং (সিন ১) ===============
export const Building: React.FC<{t: number}> = ({t}) => {
  const fr = useCurrentFrame();
  const wins: React.ReactNode[] = [];
  for (let r = 0; r < 6; r++) for (let c = 0; c < 4; c++) {
    const x = 590 + c * 200, y = 190 + r * 135, kit = r === 2 && c === 1;
    const off = 0.4 + (r * 4 + c) * 0.17;
    const lit = kit || t < off || (t < off + 0.12 && fr % 4 < 2);
    wins.push(
      <g key={`${r}${c}`}>
        <R x={x} y={y} w={120} h={96} f={lit ? '#FFD36B' : '#1B2236'} sw={4} />
        <line x1={x + 60} x2={x + 60} y1={y} y2={y + 96} stroke={ink} strokeWidth={3} />
        <R x={x - 10} y={y + 100} w={140} h={10} f="#3C3A52" sw={2.5} />
      </g>,
    );
  }
  return (
    <Svg>
      <defs>
        <linearGradient id="skyB" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#070C26" /><stop offset="1" stopColor="#26356E" /></linearGradient>
        <radialGradient id="winG"><stop offset="0" stopColor="#FFD36B" stopOpacity=".7" /><stop offset="1" stopColor="#FFD36B" stopOpacity="0" /></radialGradient>
      </defs>
      <rect width="1920" height="1080" fill="url(#skyB)" />
      {stars.map((s, i) => <circle key={i} cx={s[0]} cy={s[1]} r={s[2] * 0.8} fill="#fff" opacity={0.5 + ((i + Math.floor(fr / 8)) % 3) * 0.2} />)}
      <circle cx={1560} cy={170} r={66} fill="#FFF6D6" /><circle cx={1590} cy={150} r={60} fill="#0E1640" />
      {[[40, 420, 200], [260, 520, 160], [1440, 480, 180], [1640, 380, 220]].map(([x, y, w], i) => (
        <g key={i}><rect x={x} y={y} width={w} height={1080 - y} fill="#141B3F" />{[0, 1, 2].map((k) => <rect key={k} x={x + 24 + k * 50} y={y + 40 + (k % 2) * 90} width={26} height={34} fill={k === 1 ? '#7A6A45' : '#222B55'} />)}</g>
      ))}
      <R x={520} y={130} w={880} h={900} f="#5A5876" sw={5} />
      <R x={700} y={64} w={120} h={66} f="#7B7A92" sw={4} /><line x1={1200} x2={1200} y1={130} y2={50} stroke={ink} strokeWidth={5} />
      {wins}
      <circle cx={850} cy={508} r={190 + Math.sin(fr / 9) * 12} fill="url(#winG)" />
      <R x={880} y={930} w={120} h={100} f="#2A2740" sw={4} />
      <rect y="1010" width="1920" height="70" fill="#1B1F30" />
      <line x1={380} x2={380} y1={640} y2={1010} stroke={ink} strokeWidth={10} /><circle cx={380} cy={630} r={26} fill="#FFE79A" stroke={ink} strokeWidth={3} />
      <circle cx={380} cy={630} r={120} fill="url(#winG)" opacity={0.5} />
    </Svg>
  );
};

// =============== ইয়ামিনের স্টেশনারি দোকান ===============
const Shelf = ({y, kind}: {y: number; kind: number}) => {
  const cols = ['#D64545', '#2F6EA8', '#F2C94C', '#4CAF7A', '#8E5AB5', '#F2994A', '#E85D75'];
  const items: React.ReactNode[] = [];
  for (let i = 0; i < 17; i++) {
    const x = 410 + i * 64;
    if (kind === 0) items.push(<g key={i}><R x={x} y={y - 38 - (i % 3) * 8} w={54} h={38 + (i % 3) * 8} f={i % 4 === 0 ? '#fff' : cols[i % 7]} sw={2.5} />{i % 4 === 0 && <rect x={x} y={y - 24} width={54} height={8} fill="#2F6EA8" />}</g>);
    else if (kind === 1) items.push(i % 3 === 0
      ? <g key={i}><R x={x} y={y - 48} w={50} h={48} f="#E8E1D0" r={6} sw={2.5} />{[0, 1, 2].map((k) => <line key={k} x1={x + 12 + k * 13} x2={x + 8 + k * 16} y1={y - 48} y2={y - 76} stroke={cols[(i + k) % 7]} strokeWidth={5} strokeLinecap="round" />)}</g>
      : <R key={i} x={x} y={y - 34} w={54} h={34} f={i % 3 === 1 ? '#F2C94C' : '#6FB6E6'} r={4} sw={2.5} />);
    else items.push(<R key={i} x={x + 4} y={y - 70 + (i % 4) * 8} w={22} h={70 - (i % 4) * 8} f={cols[(i * 3) % 7]} sw={2.5} />);
  }
  return <g>{items}<R x={390} y={y} w={750 + 200} h={14} f="#8B5E3C" sw={3} /></g>;
};

export const Shop: React.FC = () => {
  const stripes = Array.from({length: 24}, (_, i) => i);
  return (
    <Svg>
      <rect width="1920" height="1080" fill="#F4E8CF" />
      <rect y="920" width="1920" height="160" fill="#8E9096" /><rect y="900" width="1920" height="30" fill="#BDBDB8" /><line x1={0} x2={1920} y1={1000} y2={1000} stroke="#F5F5F5" strokeWidth={8} strokeDasharray="60 40" />
      {/* সাইনবোর্ড */}
      <R x={420} y={22} w={1080} h={138} f="#1F5C46" r={18} sw={5} /><rect x={434} y={34} width={1052} height={114} rx={12} fill="none" stroke="#E8B923" strokeWidth={4} />
      <text x={960} y={100} textAnchor="middle" fontSize={72} fontWeight={700} fill="#fff">ইয়ামিন স্টেশনারি</text>
      <text x={960} y={140} textAnchor="middle" fontSize={28} fontWeight={600} fill="#FFE08A">খাতা • কলম • কাগজ • স্কুল ব্যাগ • গিফট আইটেম</text>
      {/* শেড */}
      {stripes.map((i) => <g key={i}><rect x={i * 80} y={170} width={80} height={80} fill={i % 2 ? '#fff' : '#D9483B'} stroke={ink} strokeWidth={3} /><circle cx={i * 80 + 40} cy={250} r={40} fill={i % 2 ? '#fff' : '#D9483B'} stroke={ink} strokeWidth={3} /></g>)}
      <rect y={168} width={1920} height={60} fill="none" /><rect y="236" width="1920" height="10" fill="#F4E8CF" opacity={0} />
      {/* ভেতরের অংশ */}
      <R x={120} y={290} w={1680} h={470} f="#FBEBC2" sw={5} />
      <rect x={124} y={294} width={1672} height={30} fill="#E0C98A" />
      <Shelf y={440} kind={0} /><Shelf y={570} kind={1} /><Shelf y={700} kind={2} />
      <R x={130} y={324} w={250} h={20} f="#8B5E3C" /><R x={1540} y={324} w={250} h={20} f="#8B5E3C" />
      {/* ঝুলন্ত স্কুল ব্যাগ */}
      {[[170, '#2F6EA8'], [270, '#D64545'], [1560, '#4CAF7A'], [1670, '#8E5AB5']].map(([x, c], i) => (
        <g key={i}><line x1={(x as number) + 40} x2={(x as number) + 40} y1={344} y2={380} stroke={ink} strokeWidth={4} /><R x={x as number} y={380} w={80} h={110} f={c as string} r={16} /><R x={(x as number) + 10} y={430} w={60} h={40} f="#fff" r={8} sw={2.5} o={0.5} /></g>
      ))}
      <R x={160} y={560} w={190} h={120} f="#FFF3A8" /><text x={255} y={606} textAnchor="middle" fontSize={34} fontWeight={700} fill="#D64545">খাতা</text><text x={255} y={650} textAnchor="middle" fontSize={34} fontWeight={700} fill={ink}>কলম • কাগজ</text>
      <R x={1560} y={560} w={190} h={120} f="#CFE8F2" /><text x={1655} y={606} textAnchor="middle" fontSize={30} fontWeight={700} fill="#2F6EA8">স্কুলের</text><text x={1655} y={648} textAnchor="middle" fontSize={34} fontWeight={700} fill={ink}>সব জিনিস</text>
      {/* কাউন্টার */}
      <R x={100} y={745} w={1720} h={30} f="#6A4A2C" r={4} />
      <R x={110} y={775} w={1700} h={140} f="#9C6B3F" />
      <R x={150} y={790} w={1090} h={108} f="#CFE8F2" sw={4} o={0.95} />
      {Array.from({length: 11}).map((_, i) => <g key={i}><R x={166 + i * 98} y={846 + (i % 2) * 6} w={72} h={44 - (i % 2) * 6} f={['#F2C94C', '#6FB6E6', '#E85D75', '#7BC47F'][i % 4]} sw={2.5} r={4} /><line x1={176 + i * 98} x2={226 + i * 98} y1={822} y2={812} stroke={['#D64545', '#2F6EA8', '#222'][i % 3]} strokeWidth={5} strokeLinecap="round" /></g>)}
      {[0, 1, 2].map((i) => <R key={i} x={1280 + i * 175} y={795} w={160} h={105} f="#AA7A4A" r={4} sw={2.5} />)}
      {/* কাউন্টারের ওপর */}
      <g transform="translate(1420 700)"><R x={-40} y={-48} w={80} h={96} f="#3B3F4A" r={10} /><R x={-30} y={-38} w={60} h={22} f="#B8E0C0" sw={2.5} />{[0, 1, 2].map((r) => [0, 1, 2].map((c) => <rect key={r * 3 + c} x={-28 + c * 20} y={-8 + r * 16} width={16} height={11} rx={2} fill="#D9DDE3" stroke={ink} strokeWidth={1.5} />))}</g>
      <R x={1280} y={706} w={100} h={40} f="#D64545" r={4} /><text x={1330} y={735} textAnchor="middle" fontSize={26} fontWeight={700} fill="#fff">বাকির খাতা</text>
      <R x={1540} y={712} w={120} h={34} f="#7B7A92" r={4} /><R x={1700} y={690} w={50} h={56} f="#fff" r={6} />
      {[1712, 1722, 1732].map((x, i) => <line key={x} x1={x} x2={x + (i - 1) * 5} y1={692} y2={664} stroke={['#D64545', '#2F6EA8', '#4CAF7A'][i]} strokeWidth={6} strokeLinecap="round" />)}
      {/* দুই পাশের থাম ও সাজসজ্জা */}
      <R x={0} y={290} w={120} h={630} f="#E5D2AE" sw={4} /><R x={1800} y={290} w={120} h={630} f="#E5D2AE" sw={4} />
      <R x={20} y={820} w={80} h={90} f="#C86B5B" r={8} /><path d="M60 820 Q20 760 40 700 Q70 760 60 820 M60 820 Q100 750 80 690 Q50 760 60 820" fill="#4CAF7A" stroke={ink} strokeWidth={3} />
      <R x={1815} y={420} w={90} h={130} f="#FFF8E1" /><text x={1860} y={470} textAnchor="middle" fontSize={30} fontWeight={700} fill="#D64545">খোলা</text><text x={1860} y={516} textAnchor="middle" fontSize={26} fontWeight={600} fill={ink}>সকাল ৯টা</text>
    </Svg>
  );
};
