import React from 'react';
import {Easing, useCurrentFrame} from 'remotion';
import {C} from './config';

export type Pose = {h: number; la: number; lb: number; ra: number; rb: number; lean: number; tilt: number; walk: number};
export const STAND: Pose = {h: 190, la: 8, lb: -6, ra: 8, rb: -6, lean: 0, tilt: 0, walk: 0};
export const HOLD = {la: 15, lb: -99, ra: 15, rb: -99};
export type Expr = 'neutral' | 'tired' | 'sad' | 'worried' | 'surprised' | 'happy' | 'smile' | 'think' | 'cry';

export const mix = (t: number, keys: [number, Partial<Pose>][]): Pose => {
  const full = keys.map(([s, p]) => [s, {...STAND, ...p}] as [number, Pose]);
  if (t <= full[0][0]) return {...full[0][1]};
  for (let i = 1; i < full.length; i++) {
    if (t <= full[i][0]) {
      const [a, pa] = full[i - 1];
      const [b, pb] = full[i];
      const k = Easing.inOut(Easing.cubic)((t - a) / Math.max(0.001, b - a));
      const o: any = {};
      (Object.keys(pa) as (keyof Pose)[]).forEach((key) => { o[key] = pa[key] + (pb[key] - pa[key]) * k; });
      return o;
    }
  }
  return {...full[full.length - 1][1]};
};

const EX: Record<Expr, {brow: number; by: number; mouth: string; lid: number; big?: number}> = {
  neutral: {brow: 0, by: 0, mouth: 'flat', lid: 0},
  tired: {brow: -5, by: 7, mouth: 'flat', lid: 0.42},
  sad: {brow: 15, by: 3, mouth: 'frown', lid: 0.22},
  worried: {brow: 13, by: -3, mouth: 'wavy', lid: 0},
  surprised: {brow: -6, by: -16, mouth: 'o', lid: 0, big: 1.25},
  happy: {brow: -4, by: -5, mouth: 'big', lid: 0},
  smile: {brow: -2, by: -1, mouth: 'smile', lid: 0},
  think: {brow: 7, by: -3, mouth: 'side', lid: 0.12},
  cry: {brow: 17, by: 3, mouth: 'frown', lid: 0.25},
};

const Cap: React.FC<{a: number[]; b: number[]; w: number; fill: string}> = ({a, b, w, fill}) => (
  <g strokeLinecap="round">
    <line x1={a[0]} y1={a[1]} x2={b[0]} y2={b[1]} stroke={C.ink} strokeWidth={w + 6} />
    <line x1={a[0]} y1={a[1]} x2={b[0]} y2={b[1]} stroke={fill} strokeWidth={w} />
  </g>
);

type CP = {
  who: 'yamin' | 'zarna'; x: number; y: number; s?: number; flip?: boolean; pose: Pose; expr?: Expr;
  talk?: boolean; look?: [number, number]; holdL?: React.ReactNode; holdR?: React.ReactNode; shake?: number; seed?: number;
};

export const Character: React.FC<CP> = ({who, x, y, s = 0.9, flip, pose, expr = 'neutral', talk, look = [0, 0], holdL, holdR, shake = 0, seed = 0}) => {
  const fr = useCurrentFrame();
  const Y = who === 'yamin';
  const skin = Y ? '#B07A52' : '#CD9A70';
  const hair = '#1B1B1B';
  const top = Y ? '#1F5E3A' : '#F2A3BE';
  const pant = Y ? '#2B2B2B' : '#F7F7F7';
  const shoe = Y ? '#161616' : '#9A8F85';
  const {h, la, lb, ra, rb, lean, tilt, walk} = pose;
  const hipY = -h, bt = hipY - 215, bw = Y ? 124 : 112;
  const idle = Math.sin(fr / 14 + seed) * 3;
  const sw = Math.sin(fr * 0.5) * walk;
  const jx = shake ? Math.sin(fr * 2.7) * shake : 0;
  const jy = shake ? Math.cos(fr * 3.1) * shake * 0.6 : 0;
  const ex = EX[expr];
  const bf = (fr + seed * 11) % 100;
  const blink = bf < 5 ? Math.sin((bf / 5) * Math.PI) : 0;
  const shape = talk ? [1, 2, 1, 0, 2, 1, 0, 2][Math.floor(fr / 3) % 8] : -1;
  const lw = Y ? 46 : 42;

  // ---------- পা ----------
  const shoeEl = (p: number[], sd: number) => <ellipse cx={p[0] + sd * 5} cy={p[1] + 4} rx={34} ry={13} fill={shoe} stroke={C.ink} strokeWidth={3} />;
  const legs = [-1, 1].map((sd) => {
    if (h >= 150) {
      const L = h - 16, ang = (sd * sw * 28 * Math.PI) / 180;
      const foot = [sd * 26 + Math.sin(ang) * L, hipY + Math.cos(ang) * L];
      return <g key={sd}><Cap a={[sd * 26, hipY]} b={foot} w={lw} fill={pant} />{shoeEl(foot, sd)}</g>;
    }
    if (h >= 55) {
      const knee = [sd * 46, -h + 52], foot = [sd * 52, -14];
      return <g key={sd}><Cap a={[sd * 26, hipY]} b={knee} w={lw} fill={pant} /><Cap a={knee} b={foot} w={lw - 4} fill={pant} />{shoeEl(foot, sd)}</g>;
    }
    const knee = [sd * 125, -16], foot = [sd * 16, -8];
    return <g key={sd}><Cap a={[sd * 22, hipY]} b={knee} w={lw} fill={pant} /><Cap a={knee} b={foot} w={lw - 6} fill={pant} />{shoeEl(foot, sd)}</g>;
  });

  // ---------- হাত ----------
  const dir = (sd: number, deg: number) => [sd * Math.sin((deg * Math.PI) / 180), Math.cos((deg * Math.PI) / 180)];
  const arm = (sd: number, a: number, b: number, hold: React.ReactNode) => {
    const a2 = a + sd * sw * 16;
    const sx = sd * (bw / 2 + 2), sy = bt + 38;
    const d1 = dir(sd, a2), d2 = dir(sd, a2 + b);
    const E = [sx + d1[0] * 104, sy + d1[1] * 104];
    const Hd = [E[0] + d2[0] * 96, E[1] + d2[1] * 96];
    const at = (k: number) => [Hd[0] - d2[0] * k, Hd[1] - d2[1] * k];
    const seg = (p: number[], k: number) => [p[0] + d2[0] * k, p[1] + d2[1] * k];
    return (
      <g key={sd}>
        <Cap a={[sx, sy]} b={E} w={38} fill={top} />
        <Cap a={E} b={Hd} w={34} fill={skin} />
        {Y && <Cap a={E} b={seg(E, 16)} w={44} fill="#2E7A4C" />}
        {!Y && [26, 40].map((k) => <Cap key={k} a={at(k)} b={seg(at(k), 5)} w={38} fill="#2E9E5B" />)}
        {Y && sd === 1 && <Cap a={at(32)} b={seg(at(32), 12)} w={40} fill="#1A1A1A" />}
        <circle cx={Hd[0]} cy={Hd[1]} r={19} fill={skin} stroke={C.ink} strokeWidth={3} />
        {hold && <g transform={`translate(${Hd[0]} ${Hd[1]})`}>{hold}</g>}
      </g>
    );
  };

  // ---------- শরীর ----------
  const hem = Math.min(hipY + 95, -10);
  const torso = Y ? (
    <g>
      <rect x={-bw / 2} y={bt} width={bw} height={232} rx={42} fill={top} stroke={C.ink} strokeWidth={3} />
      <path d={`M-26 ${bt + 2} L0 ${bt + 46} L-38 ${bt + 36} Z M26 ${bt + 2} L0 ${bt + 46} L38 ${bt + 36} Z`} fill="#17492C" stroke={C.ink} strokeWidth={3} strokeLinejoin="round" />
      <line x1={0} y1={bt + 46} x2={0} y2={hipY + 14} stroke={C.ink} strokeWidth={3} />
      {[70, 110, 150, 190].map((o) => <circle key={o} cx={0} cy={bt + o} r={4} fill="#D9E8DD" stroke={C.ink} strokeWidth={2} />)}
      <rect x={20} y={bt + 82} width={30} height={34} rx={4} fill="none" stroke={C.ink} strokeWidth={2.5} />
      <path d={`M-48 ${hipY - 40} q16 10 30 -2 M30 ${hipY - 70} q14 8 22 0`} fill="none" stroke="#17492C" strokeWidth={3} strokeLinecap="round" />
    </g>
  ) : (
    <g>
      <path d={`M-54 ${bt + 34} C-54 ${bt - 4} 54 ${bt - 4} 54 ${bt + 34} L56 ${bt + 150} L74 ${hem} L-74 ${hem} L-56 ${bt + 150} Z`} fill={top} stroke={C.ink} strokeWidth={3} strokeLinejoin="round" />
      <path d={`M-72 ${hem - 14} L72 ${hem - 14}`} stroke="#fff" strokeWidth={8} />
      <path d={`M-22 ${bt + 4} Q0 ${bt + 44} 22 ${bt + 4} Z`} fill={skin} stroke={C.ink} strokeWidth={2.5} />
      <path d={`M-18 ${bt + 30} Q0 ${bt + 52} 18 ${bt + 30}`} fill="none" stroke="#fff" strokeWidth={4} />
      {/* ওড়না — রাতে একটু আলগা */}
      <path d={`M-54 ${bt + 26} C-30 ${bt + 62} 30 ${bt + 66} 56 ${bt + 26} L64 ${bt + 38} C72 ${bt + 110} 66 ${bt + 170} 42 ${bt + 196} L22 ${bt + 154} C32 ${bt + 112} 12 ${bt + 84} -10 ${bt + 76} L-52 ${bt + 40} Z`} fill="#fff" stroke={C.ink} strokeWidth={3} strokeLinejoin="round" />
    </g>
  );

  // ---------- মাথা ----------
  const rx = Y ? 62 : 68, ry = Y ? 82 : 72, eX = Y ? 27 : 29, eY = Y ? -4 : 0;
  const eRx = Y ? 14 : 17, eRy = (Y ? 16 : 20) * (1 - blink * 0.95) * (ex.big || 1);
  const mY = Y ? 52 : 40;
  const ink = {stroke: C.ink, strokeWidth: 4, fill: 'none', strokeLinecap: 'round' as const};
  const mouth = () => {
    if (shape >= 1) {
      const mrx = shape === 1 ? 11 : 16, mry = shape === 1 ? 6 : 14;
      return <g><ellipse rx={mrx} ry={mry} fill="#7A2630" stroke={C.ink} strokeWidth={3} />{shape === 2 && <ellipse cy={mry * 0.5} rx={mrx * 0.6} ry={mry * 0.4} fill="#E56B7B" />}</g>;
    }
    if (shape === 0) return <path d="M-12 0 Q0 6 12 0" {...ink} />;
    switch (ex.mouth) {
      case 'smile': return <path d="M-20 -3 Q0 17 20 -3" {...ink} />;
      case 'big': return <g><path d="M-24 -5 Q0 30 24 -5 Z" fill="#7A2630" stroke={C.ink} strokeWidth={3} strokeLinejoin="round" /><path d="M-18 -3 Q0 3 18 -3 L16 4 Q0 8 -16 4 Z" fill="#fff" /></g>;
      case 'frown': return <path d="M-16 7 Q0 -9 16 7" {...ink} />;
      case 'wavy': return <path d="M-17 3 Q-8.5 -4 0 3 T17 3" {...ink} />;
      case 'o': return <ellipse rx={9} ry={12} fill="#7A2630" stroke={C.ink} strokeWidth={3} />;
      case 'side': return <path d="M-12 3 L14 -3" {...ink} />;
      default: return <path d="M-14 0 L14 0" {...ink} />;
    }
  };
  const eye = (sd: number) => (
    <g key={sd} transform={`translate(${sd * eX} ${eY})`}>
      <clipPath id={`ec-${who}-${sd}`}><ellipse rx={eRx} ry={Math.max(eRy, 1)} /></clipPath>
      <ellipse rx={eRx} ry={Math.max(eRy, 1)} fill="#fff" stroke={C.ink} strokeWidth={3} />
      <g clipPath={`url(#ec-${who}-${sd})`}>
        <circle cx={look[0] * 6} cy={look[1] * 6} r={8} fill={C.ink} />
        <circle cx={look[0] * 6 + 3} cy={look[1] * 6 - 3} r={2.6} fill="#fff" />
        {ex.lid > 0 && <rect x={-eRx - 2} y={-eRy - 2} width={eRx * 2 + 4} height={ex.lid * eRy * 2 + 2} fill={skin} stroke={C.ink} strokeWidth={2.5} />}
      </g>
      {Y && <path d="M-13 24 Q0 33 13 24" fill="none" stroke="#4A2F20" strokeWidth={3} opacity={0.75} strokeLinecap="round" />}
      <g transform={`translate(0 ${-28 + ex.by}) rotate(${sd * ex.brow})`}>
        <line x1={-18} x2={18} y1={0} y2={0} stroke={hair} strokeWidth={Y ? 9 : 7} strokeLinecap="round" />
      </g>
      {expr === 'cry' && <ellipse cx={sd * 3} cy={26 + ((fr * 2.5 + (sd > 0 ? 17 : 0)) % 44)} rx={5} ry={8} fill="#8FD3FF" stroke={C.ink} strokeWidth={1.5} />}
    </g>
  );

  const head = (
    <g transform={`translate(0 ${bt - 62}) rotate(${tilt})`}>
      {!Y && <ellipse cx={0} cy={-4} rx={75} ry={80} fill={hair} stroke={C.ink} strokeWidth={3} />}
      <ellipse cx={-rx + 2} cy={6} rx={11} ry={16} fill={skin} stroke={C.ink} strokeWidth={3} />
      <ellipse cx={rx - 2} cy={6} rx={11} ry={16} fill={skin} stroke={C.ink} strokeWidth={3} />
      {!Y && <><circle cx={-rx - 4} cy={26} r={7} fill="#E8B923" stroke={C.ink} strokeWidth={2} /><circle cx={rx + 4} cy={26} r={7} fill="#E8B923" stroke={C.ink} strokeWidth={2} /></>}
      <ellipse cx={0} cy={0} rx={rx} ry={ry} fill={skin} stroke={C.ink} strokeWidth={3} />
      {Y && <path d="M-52 38 Q0 106 52 38 Q0 74 -52 38 Z" fill="#3B2D26" opacity={0.28} />}
      {!Y && <><circle cx={-46} cy={22} r={14} fill="#F08080" opacity={0.35} /><circle cx={46} cy={22} r={14} fill="#F08080" opacity={0.35} /></>}
      {Y ? (
        <g>
          <path d="M-66 -12 C-74 -118 76 -126 66 -12 C60 -44 34 -60 6 -56 C-24 -52 -52 -44 -66 -12 Z" fill={hair} stroke={C.ink} strokeWidth={3} strokeLinejoin="round" />
          <path d="M-22 -92 Q-14 -76 -8 -58 M20 -94 q8 10 6 22" stroke="#555" strokeWidth={3} fill="none" strokeLinecap="round" />
          <path d="M-26 66 L-22 70 M-12 74 L-10 78 M6 76 L8 80 M20 72 L22 76 M-34 56 L-30 60 M32 58 L36 62" stroke="#2c2018" strokeWidth={3} strokeLinecap="round" />
        </g>
      ) : (
        <g>
          <path d="M-70 -8 C-76 -92 76 -92 70 -8 C54 -46 20 -58 0 -58 C-20 -58 -54 -46 -70 -8 Z" fill={hair} stroke={C.ink} strokeWidth={3} strokeLinejoin="round" />
          <circle cx={0} cy={-90} r={30} fill={hair} stroke={C.ink} strokeWidth={3} />
          <rect x={-18} y={-66} width={36} height={8} rx={4} fill="#E07BA0" stroke={C.ink} strokeWidth={2} />
          <circle cx={0} cy={-30} r={5} fill={C.ink} />
        </g>
      )}
      {eye(-1)}{eye(1)}
      {Y && <path d="M-26 34 Q-12 24 0 31 Q12 24 26 34 Q12 40 0 36 Q-12 40 -26 34 Z" fill="#1c1c1c" stroke={C.ink} strokeWidth={2} />}
      <g transform={`translate(0 ${mY})`}>{mouth()}</g>
    </g>
  );

  return (
    <g transform={`translate(${x + jx} ${y + jy}) scale(${flip ? -s : s} ${s})`}>
      <ellipse cx={0} cy={4} rx={h < 55 ? 190 : 110} ry={18} fill="rgba(0,0,0,0.2)" />
      <g transform={`translate(0 ${idle * 0.6})`}>
        {legs}
        <g transform={`rotate(${lean} 0 ${hipY})`}>
          {torso}
          <rect x={-16} y={bt - 18} width={32} height={34} fill={skin} stroke={C.ink} strokeWidth={3} />
          {arm(-1, la, lb, holdL)}
          {arm(1, ra, rb, holdR)}
          {head}
        </g>
      </g>
    </g>
  );
};
