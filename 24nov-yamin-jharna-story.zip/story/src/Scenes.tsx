import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile} from 'remotion';
import {B, C, SceneCtx, f, fontFamily, kfn, ramp, useT} from './config';
import {Character, HOLD, mix} from './Character';
import {Arrow, Book, Calculator, CheckIc, ClockIc, Coin, Cup, Flame, Glass, Heart, Kettle, Kid, Lock, Mahajan, Notice, Papers, QMark, Steam, Sun, Tin, Sack} from './Icons';
import {Building, Home, Landing, Shop} from './Backgrounds';
import {Bubble, Cam, Captions, Fade, IcoBox, Pill, Pop, Shake, Stamp} from './UI';

const TIN = {x: 1330, y: 985};
const CAP = {
  s1: [{a: 0.24, b: 3.94, t: 'রাত **দুটোয়** ফ্ল্যাটের সব বাতি নিভে গেলেও'}, {a: 3.94, b: 5.56, t: '**রান্নাঘরের** আলোটা জ্বলছিল।'}],
  s2: [{a: 5.56, b: 8.0, t: 'ঝর্ণা **পানি** খেতে উঠে দেখল,'}, {a: 8.0, b: 10.66, t: 'ইয়ামিন মেঝেতে **পিঠ ঠেকিয়ে** বসে আছে।'}, {a: 10.66, b: 13.86, t: 'সামনে **calculator** আর একগাদা কাগজ।'}, {a: 13.86, b: 16.0, t: 'ঝর্ণাকে দেখেই সে **কাগজগুলো**'}, {a: 16.0, b: 18.0, t: 'চালের **ড্রামের** পেছনে ঠেলে দিয়ে'}],
  s4: [{a: 21.0, b: 23.1, t: 'এক **সন্ধ্যায়** ঝর্ণা একটা পুরনো বিস্কুটের'}, {a: 23.1, b: 25.58, t: '**টিন** এনে ইয়ামিনের সামনে রাখল।'}, {a: 25.58, b: 28.34, t: '**ঢাকনা খুলতেই** বেরোল ভাঁজ করা'}, {a: 28.34, b: 29.86, t: '**নোট** আর **খুচরো**।'}],
  s5: [{a: 33.6, b: 36.9, t: 'ইয়ামিন টিনটার দিকে **তাকিয়ে রইল**। তারপর'}],
  s6: [{a: 42.4, b: 43.88, t: 'সে **দরজা ঠেলে** বেরিয়ে'}, {a: 43.88, b: 45.5, t: 'সিঁড়ির **landing** গিয়ে বসল।'}],
  s7: [{a: 45.5, b: 48.08, t: 'ঝর্ণা **টিনটা সরাল না**, শুধু'}, {a: 48.08, b: 50.56, t: 'চুলায় চায়ের পানি **বসিয়ে দিল**।'}],
  s8: [{a: 50.56, b: 53.48, t: 'ঝর্ণা দুই **কাপ চা** নিয়ে সিঁড়িতে'}, {a: 53.48, b: 55.14, t: 'ইয়ামিনের **পাশে বসল**।'}, {a: 55.14, b: 57.64, t: 'দুজনে অনেকক্ষণ **কিছু বলল না**।'}],
  s9: [{a: 57.64, b: 60.0, t: 'তারপর ইয়ামিন **নিজেই** উঠে ভেতরে গিয়ে'}, {a: 60.0, b: 62.5, t: 'চালের **ড্রামের** পেছন থেকে নোটিশটা বের করে'}],
  s11: [{a: 76.88, b: 80.22, t: '**রান্নাঘরের আলোটা** সেদিন রাতেও জ্বলছিল,'}, {a: 80.22, b: 82.02, t: 'কিন্তু এবার **মেঝেতে দুজন** বসে।'}],
};
const inSeg = (t: number, segs: [number, number][]) => segs.some(([a, b]) => t >= a && t < b);
const At: React.FC<{x: number; y: number; s?: number; r?: number; children: React.ReactNode}> = ({x, y, s = 1, r = 0, children}) => (
  <g transform={`translate(${x} ${y}) rotate(${r}) scale(${s})`}>{children}</g>
);
const Overlay: React.FC<{children: React.ReactNode}> = ({children}) => <AbsoluteFill>{children}</AbsoluteFill>;
const SvgFull: React.FC<{children: React.ReactNode}> = ({children}) => (
  <svg viewBox="0 0 1920 1080" width="100%" height="100%" style={{position: 'absolute', left: 0, top: 0, fontFamily}}>{children}</svg>
);
const TinOpen: React.FC<{o?: number}> = ({o = 1}) => <At x={TIN.x} y={TIN.y} s={0.9}><Tin open={o} /></At>;

// ---------- সিন ১: রাতের বিল্ডিং ----------
const S1 = () => {
  const {t} = useT();
  return (
    <AbsoluteFill>
      <Cam s={kfn(t, [[0, 1], [5.56, 1.35]])} ox={850} oy={508}><Building t={t} /></Cam>
      <Pill a={0.4} b={5.3} left={60} top={50} text="রাত ২:০০" color="#FFD54A" icon={<ClockIc />} />
      <Captions items={CAP.s1} />
    </AbsoluteFill>
  );
};

// ---------- সিন ২: রান্নাঘর (রাত) ----------
const S2 = () => {
  const {t} = useT();
  const zx = kfn(t, [[0, 1500], [2.0, 340], [3.8, 340], [4.6, 440]]);
  const zy = kfn(t, [[0, 1010], [2.0, 985], [4.6, 975]]);
  const G = {ra: 15, rb: -99};
  const zp = mix(t, [[0, {walk: 1, ...G}], [1.9, {walk: 1, ...G}], [2.2, {walk: 0, ...G}], [2.6, {ra: -20, rb: -160}], [3.3, {ra: -20, rb: -160}], [3.7, {walk: 0, ...G}], [3.9, {walk: 1, ...G}], [4.4, {walk: 1, ...G}], [4.7, {walk: 0, ...G}]]);
  const yBase = {h: 30, la: 25, lb: 15, ra: 18, rb: 12, tilt: 10, lean: 6};
  const yp = mix(t, [[0, yBase], [8.0, yBase], [8.4, {...yBase, ra: 70, rb: 5, tilt: 0, lean: 0}], [10.2, {...yBase, ra: 70, rb: 5, tilt: 0, lean: 0}], [10.9, {...yBase, ra: 18, rb: 12, tilt: 0, lean: 0}]]);
  if (t < 8) yp.ra += Math.sin(t * 14) * 5;
  const px = kfn(t, [[0, 790], [8.4, 790], [10.4, 850]]);
  const py = kfn(t, [[0, 945], [8.4, 945], [10.4, 750]]);
  const ps = kfn(t, [[0, 1], [8.4, 1], [10.4, 0.7]]);
  return (
    <AbsoluteFill>
      <Shake amp={t > 8.1 && t < 9 ? 3 : 0}>
        <Home mood="night">
          <Character who="yamin" x={600} y={955} pose={yp} expr={t < 8.1 ? 'tired' : t < 9 ? 'surprised' : 'smile'} look={t < 8.1 ? [0, 0.7] : [-1, 0]} />
          <At x={690} y={905} s={0.8}><Calculator /></At>
          <At x={px} y={py} s={ps} r={-8}><Papers n={5} /></At>
          {t > 0.2 && <Character who="zarna" x={zx} y={zy} s={0.84} pose={zp} expr={t < 3.2 ? 'neutral' : 'worried'} look={t > 3.0 ? [1, 0.4] : [0, 0]} holdR={<g transform="translate(0 -6)"><Glass /></g>} seed={3} />}
        </Home>
      </Shake>
      <Overlay>
        <Pill a={0.2} b={2.4} left={60} top={50} text="রান্নাঘর • রাত" color="#CFE8F2" icon={<ClockIc size={0.9} />} />
        <Pill a={2.3} b={4.6} left={200} top={420} text="ঝর্ণা • ৩০" color="#F7B6CC" />
        <Pill a={4.6} b={7.0} left={440} top={520} text="ইয়ামিন • ৩৪" color="#9ED8B0" />
        <Pop a={3.3} b={6.0} style={{left: 360, top: 310}}><IcoBox size={110}><QMark /></IcoBox></Pop>
        <Pop a={5.1} b={8.3} style={{left: 560, top: 380}}><div style={{display: 'flex'}}><IcoBox size={120}><g transform="scale(.8)"><Calculator /></g></IcoBox><IcoBox size={120}><g transform="scale(.8)"><Papers n={3} /></g></IcoBox></div></Pop>
        <Captions items={CAP.s2} />
      </Overlay>
    </AbsoluteFill>
  );
};

// ---------- সিন ৩: ইয়ামিনের সংলাপ ----------
const S3 = () => {
  const {t} = useT();
  const yBase = {h: 30, la: 25, lb: 15, ra: 18, rb: 12, lean: 0};
  return (
    <AbsoluteFill>
      <Cam s={kfn(t, [[0, 1], [1.2, 1.15]])} ox={600} oy={640}>
        <Home mood="night">
          <Character who="yamin" x={600} y={955} pose={mix(t, [[0, yBase], [3, {...yBase, ra: 40, rb: -10}]])} expr="smile" talk={inSeg(t, [[0.08, 1.4], [1.5, 2.45]])} shake={0.8} look={[-1, 0]} />
          <At x={690} y={905} s={0.8}><Calculator /></At>
          <Character who="zarna" x={440} y={975} s={0.84} pose={{...mix(t, [[0, {...HOLD, la: 8, lb: -6}]])}} expr="worried" look={[1, 0.4]} holdR={<g transform="translate(0 -6)"><Glass /></g>} seed={3} />
        </Home>
      </Cam>
      <Bubble a={0.08} b={2.5} left={300} top={250} w={640} tail={300} text="হিসাব মেলাচ্ছিলাম, তুমি শুয়ে পড়।" />
    </AbsoluteFill>
  );
};

// ---------- সিন ৪: বিস্কুটের টিন ----------
const MoneyBurst: React.FC<{t: number; a: number}> = ({t, a}) => (
  <>
    {Array.from({length: 6}).map((_, i) => {
      const u = ramp(t, a + i * 0.25, a + i * 0.25 + 1.6);
      if (u <= 0 || u >= 1) return null;
      return <At key={i} x={TIN.x - 70 + i * 28 + Math.sin(u * 6 + i) * 18} y={TIN.y - 90 - u * 230} r={Math.sin(u * 8 + i) * 18} s={0.8}>{i % 2 ? <Coin /> : <g opacity={1 - u * 0.5}><g transform="scale(.9)"><NoteIcon /></g></g>}</At>;
    })}
  </>
);
const NoteIcon = () => (<g><rect x={-40} y={-22} width={80} height={44} rx={5} fill="#7BC47F" stroke={C.ink} strokeWidth={3} /><circle r={11} fill="#E9F7EA" stroke={C.ink} strokeWidth={2} /><text y={6} textAnchor="middle" fontFamily={fontFamily} fontWeight={700} fontSize={16} fill={C.ink}>৳</text></g>);

const S4 = () => {
  const {t} = useT();
  const zx = kfn(t, [[0, 700], [2.4, 1470]]);
  const tx = kfn(t, [[0, 700], [2.4, 1470], [2.6, 1470], [3.4, TIN.x]]);
  const ty = kfn(t, [[0, 757], [2.6, 757], [3.4, TIN.y]]);
  const op = kfn(t, [[4.4, 0], [5.4, 1]]);
  const zp = mix(t, [[0, {...HOLD, walk: 1}], [2.3, {...HOLD, walk: 1}], [2.6, {...HOLD, lean: 20}], [3.4, {...HOLD, lean: 20}], [3.9, {h: 30, la: 55, lb: 15, ra: 12, rb: -20}], [4.6, {h: 30, la: 55, lb: 15, ra: 12, rb: -20}], [5.3, {h: 30, la: 25, lb: 10, ra: 12, rb: -20}]]);
  const yp = mix(t, [[0, {h: 30, tilt: 8, la: 20, lb: 20, ra: 20, rb: 20}], [5.0, {h: 30, tilt: 8, la: 20, lb: 20, ra: 20, rb: 20}], [5.5, {h: 30, tilt: 0, la: 20, lb: 20, ra: 20, rb: 20}]]);
  return (
    <AbsoluteFill>
      <Home mood="evening">
        <Character who="yamin" x={1130} y={955} pose={yp} expr={t > 5.0 && t < 7.5 ? 'surprised' : t > 7.5 ? 'sad' : 'tired'} look={[1, 0.5]} />
        <Character who="zarna" x={zx} y={975} s={0.84} pose={zp} expr="smile" look={[-1, 0.3]} seed={3} />
        <At x={tx} y={ty} s={0.9}><Tin open={op} /></At>
        <MoneyBurst t={t} a={5.6} />
      </Home>
      <Overlay>
        <Pill a={0.2} b={2.8} left={60} top={50} text="সন্ধ্যা" color="#FFB86B" icon={<Sun />} />
        <Stamp a={8.86} b={12.6} left={430} top={130} title="তিন বছর ধরে জমানো টাকা" sub="পাড়ার বাচ্চাদের পড়িয়ে" icon={<Book />} rot={-2} />
        <Captions items={CAP.s4} />
      </Overlay>
    </AbsoluteFill>
  );
};

// ---------- সিন ৫: ইয়ামিনের প্রতিক্রিয়া ----------
const S5 = () => {
  const {t} = useT();
  const sit = {h: 30, tilt: 12, la: 20, lb: 20, ra: 20, rb: 20};
  const yp = mix(t, [[0, sit], [2.7, sit], [3.6, {h: 190, tilt: 0}], [4.2, {h: 190, ra: 50, rb: -40}], [5.0, {h: 190, ra: 15, rb: -20}], [6.6, {h: 190, ra: 70, rb: -30}], [7.7, {h: 190}], [8.0, {h: 190, walk: 1}], [8.8, {h: 190, walk: 1}]]);
  const yx = kfn(t, [[0, 1130], [7.9, 1130], [8.8, 2150]]);
  const talk = inSeg(t, [[3.4, 4.9], [4.92, 5.92], [6.58, 8.0]]);
  return (
    <AbsoluteFill>
      <Cam s={kfn(t, [[0, 1], [2.6, 1], [4.2, 1.25], [7.6, 1.25], [8.8, 1.1]])} ox={1130} oy={560}>
        <Shake amp={t > 4.9 && t < 6.5 ? 3 : 0}>
          <Home mood="evening">
            <Character who="yamin" x={yx} y={955} pose={yp} expr={t < 3 ? 'sad' : 'worried'} talk={talk} look={[1, 0.5]} shake={t > 3.6 ? 1 : 0.5} />
            <Character who="zarna" x={1470} y={955} s={0.84} pose={{...mix(t, [[0, {h: 30, la: 25, lb: 10, ra: 12, rb: -20}]])}} expr={t > 6.4 ? 'cry' : 'sad'} look={[-1, 0.3]} seed={3} />
            <TinOpen />
          </Home>
        </Shake>
      </Cam>
      <Overlay>
        <Bubble a={3.3} b={8.3} left={700} top={140} w={860} tail={430} text="আমি স্বামী, তোমার টাকায় হাত দেব? এটা তুলে রাখো।" size={52} />
        <Captions items={CAP.s5} />
      </Overlay>
    </AbsoluteFill>
  );
};

// ---------- সিন ৬: সিঁড়ির landing ----------
const S6 = () => {
  const {t} = useT();
  const door = kfn(t, [[0, 0], [0.5, 1], [2.4, 1], [3.1, 0.35]]);
  const yx = kfn(t, [[0, 1340], [0.6, 1340], [1.9, 980]]);
  const yp = mix(t, [[0, {}], [0.5, {walk: 1}], [1.9, {walk: 1}], [2.1, {}], [2.8, {h: 30, tilt: 14, la: 20, lb: 25, ra: 20, rb: 25}]]);
  return (
    <AbsoluteFill>
      <Landing door={door}>
        <Character who="yamin" x={yx} y={960} pose={yp} expr={t < 2 ? 'tired' : 'sad'} look={[-1, 0.4]} shake={t > 2.8 ? 1 : 0} />
      </Landing>
      <Overlay>
        <Pill a={0.3} b={2.6} left={60} top={50} text="সিঁড়ির landing" color="#CFE8F2" />
        <Captions items={CAP.s6} />
      </Overlay>
    </AbsoluteFill>
  );
};

// ---------- সিন ৭: চায়ের পানি ----------
const S7 = () => {
  const {t} = useT();
  const zx = kfn(t, [[0, 1500], [2.0, 560]]);
  const zp = mix(t, [[0, {walk: 1}], [1.9, {walk: 1}], [2.1, {}], [2.4, {ra: 120, rb: 0}], [3.0, {ra: 120, rb: 0}], [3.5, {}]]);
  const ring = 0.5 + Math.sin(t * 6) * 0.5;
  return (
    <AbsoluteFill>
      <Home mood="night">
        <TinOpen />
        {t < 1.8 && <ellipse cx={TIN.x} cy={TIN.y - 20} rx={140} ry={80} fill="none" stroke={C.gold} strokeWidth={6} opacity={ring} />}
        {t > 2.3 && <At x={470} y={584}><Kettle /></At>}
        {t > 2.8 && <At x={470} y={592}><Flame /></At>}
        {t > 3.8 && <At x={500} y={470}><Steam /></At>}
        <Character who="zarna" x={zx} y={975} s={0.84} pose={zp} expr={t < 2 ? 'sad' : 'neutral'} look={t < 1.8 ? [1, 0.5] : [-1, -0.2]} seed={3} />
      </Home>
      <Overlay>
        <Pill a={4.0} b={5.06} left={60} top={50} text="আধ ঘণ্টা পর" color="#FFD54A" icon={<ClockIc />} />
        <Captions items={CAP.s7} />
      </Overlay>
    </AbsoluteFill>
  );
};

// ---------- সিন ৮: দুই কাপ চা ----------
const S8 = () => {
  const {t} = useT();
  const door = kfn(t, [[0, 0.4], [0.3, 1], [2.2, 1], [3.2, 0.3]]);
  const zx = kfn(t, [[0, 1340], [0.5, 1340], [1.7, 1200]]);
  const zp = mix(t, [[0, HOLD], [0.5, {...HOLD, walk: 1}], [1.7, {...HOLD, walk: 1}], [1.9, HOLD], [2.7, {...HOLD, h: 30}], [3.3, {...HOLD, h: 30}], [3.9, {h: 30, la: 15, lb: -99, ra: 10, rb: -10}]]);
  const yp = mix(t, [[0, {h: 30, tilt: 14, la: 20, lb: 25, ra: 20, rb: 25}], [3.4, {h: 30, tilt: 14, la: 20, lb: 25, ra: 20, rb: 25}], [4.0, {h: 30, tilt: 6, la: 20, lb: 25, ra: 15, rb: -99}]]);
  const cup = <g transform="translate(0 6)"><Cup /></g>;
  const quiet = t > 4.58;
  return (
    <AbsoluteFill>
      <Landing door={door}>
        <Character who="yamin" x={980} y={960} pose={yp} expr={quiet ? 'sad' : 'tired'} look={[1, 0.3]} holdR={t > 3.7 ? cup : null} />
        {t > 0.3 && <Character who="zarna" x={zx} y={960} s={0.84} pose={zp} expr={quiet ? 'sad' : 'smile'} look={[-1, 0.2]} holdL={cup} holdR={t < 3.3 ? cup : null} seed={3} />}
      </Landing>
      <Overlay>
        <Pill a={0.0} b={2.0} left={60} top={50} text="আধ ঘণ্টা পর" color="#FFD54A" icon={<ClockIc />} />
        <Captions items={CAP.s8} />
      </Overlay>
    </AbsoluteFill>
  );
};

// ---------- সিন ৯: নোটিশ ----------
const S9 = () => {
  const {t} = useT();
  const H2 = {...HOLD};
  const yx = kfn(t, [[0, 1950], [2.3, 1030], [5.0, 1030], [6.2, 1260]]);
  const yp = mix(t, [[0, {walk: 1}], [2.2, {walk: 1}], [2.5, {la: 60, lb: 25}], [3.6, {la: 60, lb: 25, lean: 8}], [4.2, H2], [4.8, {...H2, walk: 1}], [6.0, {...H2, walk: 1}], [6.3, H2], [6.9, {...H2, h: 90, lean: 15}], [7.6, {h: 90, la: 50, lb: 10, ra: 50, rb: 10, lean: 15}], [8.8, {h: 90, la: 50, lb: 10, ra: 50, rb: 10, lean: 15}]]);
  const nx = kfn(t, [[3.2, 850], [4.2, 1030], [4.8, 1030], [6.3, 1260], [6.9, 1260], [7.6, 1400]]);
  const ny = kfn(t, [[3.2, 760], [4.2, 727], [6.9, 727], [7.6, 1035]]);
  const ns = kfn(t, [[3.2, 0.6], [4.2, 0.8], [7.6, 1.0]]);
  const flat = kfn(t, [[6.9, 0], [7.6, 1]]);
  return (
    <AbsoluteFill>
      <Home mood="night">
        <TinOpen />
        <g transform={`translate(${nx} ${ny}) scale(${ns} ${ns * (1 - 0.58 * flat)}) skewX(${-12 * flat})`}><Notice /></g>
        <Character who="yamin" x={yx} y={960} pose={yp} expr={t < 2.5 ? 'tired' : 'worried'} look={t < 2.5 ? [-1, 0.2] : [-0.5, 0.5]} />
      </Home>
      <Overlay>
        <Stamp a={4.86} b={8.8} left={250} top={140} title="নোটিশ" sub="চালের ড্রামের পেছনে লুকানো ছিল" icon={<g transform="scale(.5)"><Notice /></g>} rot={-3} />
        <Captions items={CAP.s9} />
      </Overlay>
    </AbsoluteFill>
  );
};

// ---------- সিন ১০: দোকান + সিদ্ধান্ত (মোশন গ্রাফিক্স) ----------
const Card: React.FC<{a: number; top: number; text: string; children: React.ReactNode}> = ({a, top, text, children}) => (
  <Pop a={a} b={10.4} style={{left: 960, top, transformOrigin: 'center'}}>
    <div style={{width: 860, background: 'rgba(255,255,255,.97)', border: `6px solid ${C.ink}`, borderRadius: 30, padding: '22px 30px', boxShadow: '0 10px 0 rgba(0,0,0,.3)', fontFamily}}>
      <div style={{display: 'flex', alignItems: 'center', gap: 22}}>
        <IcoBox size={86}><CheckIc /></IcoBox>
        <div style={{fontSize: 44, fontWeight: 700, color: C.ink, lineHeight: 1.3}}>{text}</div>
      </div>
      <svg width={800} height={150} viewBox="0 0 800 150" style={{marginTop: 8}}>{children}</svg>
    </div>
  </Pop>
);
const Lbl: React.FC<{x: number; y: number; t: string}> = ({x, y, t}) => <text x={x} y={y} textAnchor="middle" fontFamily={fontFamily} fontWeight={700} fontSize={26} fill={C.ink}>{t}</text>;

const S10 = () => {
  const {t} = useT();
  const p = (a: number) => ramp(t, a, a + 0.4);
  return (
    <AbsoluteFill>
      <Cam s={kfn(t, [[0, 1], [10.4, 1.07]])} ox={500} oy={500}><Shop /></Cam>
      <AbsoluteFill style={{background: 'linear-gradient(90deg, rgba(10,14,35,0) 38%, rgba(10,14,35,.82) 62%)'}} />
      <Overlay>
        <Pill a={0.2} b={3.0} left={60} top={190} text="ইয়ামিনের স্টেশনারি দোকান" color="#FFE08A" />
        <Pop a={0.1} b={10.4} style={{left: 960, top: 70}}>
          <div style={{display: 'flex', alignItems: 'center', gap: 18, fontFamily, fontWeight: 700, fontSize: 64, color: '#fff'}}>
            <IcoBox size={100}><g transform="scale(.8)"><Calculator /></g></IcoBox>দুজনের হিসাব
          </div>
        </Pop>
        <Card a={1.7} top={230} text="টিনের টাকা থেকে কিছুটা দিয়ে মহাজনের কাছে সময় চাওয়া হবে">
          <At x={70} y={80} s={0.6}><Tin open={1} /></At>
          <At x={175} y={70}><g opacity={p(2.2)}><Arrow c={C.ink} /></g></At>
          {[250, 305, 360].map((x, i) => <g key={x} opacity={p(2.5 + i * 0.2)}><At x={x} y={70} s={0.8}><Coin /></At></g>)}
          <At x={470} y={70}><g opacity={p(3.4)}><Arrow c={C.ink} /></g></At>
          <g opacity={p(3.7)}><At x={580} y={70} s={1}><Mahajan /></At><Lbl x={580} y={140} t="মহাজন" /></g>
          <g opacity={p(4.4)}><At x={710} y={62} s={0.7}><ClockIc /></At><Lbl x={710} y={140} t="সময়" /></g>
        </Card>
        <Card a={7.08} top={620} text="আর ঝর্ণা সকালের ব্যাচে আরও কয়েকটা বাচ্চা নেবে">
          <At x={70} y={70} s={0.9}><Sun /></At><Lbl x={70} y={142} t="সকাল" />
          <At x={175} y={70}><Arrow c={C.ink} /></At>
          {[260, 350, 440].map((x, i) => <g key={x} opacity={p(7.5 + i * 0.35)}><At x={x} y={76} s={0.95}><Kid c={['#F2994A', '#5B8DEF', '#E85D75'][i]} /></At></g>)}
          <g opacity={p(8.8)}><At x={590} y={70} s={0.9}><Book /></At><Lbl x={590} y={140} t="ব্যাচ" /></g>
          <g opacity={p(9.2)}><text x={710} y={92} textAnchor="middle" fontFamily={fontFamily} fontWeight={700} fontSize={78} fill="#2E9E5B">+</text></g>
        </Card>
      </Overlay>
    </AbsoluteFill>
  );
};

// ---------- সিন ১১: আবার সেই রান্নাঘর, এবার দুজন ----------
const S11 = () => {
  const {t} = useT();
  const s = kfn(t, [[0, 1.5], [3.5, 1]]);
  return (
    <AbsoluteFill>
      <Cam s={s} ox={470} oy={300}>
        <Home mood="cozy" pulse={kfn(t, [[0, 1], [3, 0.2], [5, 0]])}>
          <TinOpen />
          <g transform="translate(1330 1052) scale(1.1 0.46) skewX(-12)"><Notice /></g>
          <At x={1170} y={1010} s={0.5}><Calculator /></At>
          <Character who="yamin" x={1130} y={955} pose={{h: 30, la: 20, lb: 20, ra: 42, rb: 8, lean: 0, tilt: 0, walk: 0}} expr="smile" look={[1, 0.6]} />
          <Character who="zarna" x={1470} y={955} s={0.84} pose={{h: 30, la: 40, lb: 10, ra: 12, rb: -20, lean: 0, tilt: Math.sin(t * 2) * 4, walk: 0}} expr="smile" look={[-1, 0.5]} seed={3} />
        </Home>
      </Cam>
      <Captions items={CAP.s11} />
    </AbsoluteFill>
  );
};

// ---------- সিন ১২: শিক্ষা (মোশন গ্রাফিক্স) ----------
const TextCard: React.FC<{a: number; b: number; text: string; big?: boolean}> = ({a, b, text, big}) => (
  <Pop a={a} b={b} style={{left: 160, top: big ? 110 : 90, width: 1600, transformOrigin: 'center'}}>
    <div style={{fontFamily, fontWeight: 700, fontSize: big ? 104 : 64, textAlign: 'center', color: big ? C.gold : C.ink, background: big ? 'rgba(10,14,35,.78)' : 'rgba(255,255,255,.96)', border: `6px solid ${big ? C.gold : C.ink}`, borderRadius: 32, padding: '20px 40px', lineHeight: 1.3, boxShadow: '0 10px 0 rgba(0,0,0,.35)'}}>{text}</div>
  </Pop>
);

const S12 = () => {
  const {t} = useT();
  const ySit = kfn(t, [[5.7, 190], [6.4, 110]]);
  const yp = mix(t, [[0, {lean: 10, tilt: 8, la: 12, lb: -10, ra: 12, rb: -10}], [3.0, {lean: 8, tilt: 8, ...HOLD}], [5.7, {lean: 8, tilt: 8, ...HOLD}], [6.4, {h: 110, tilt: 6, la: 12, lb: -10, ra: 12, rb: -10}], [8.4, {h: 110, tilt: 0, la: 12, lb: -10, ra: 12, rb: -10, lean: 0}]]);
  yp.h = ySit;
  const chestY = kfn(t, [[0, 649], [5.7, 649], [6.4, 711]]);
  const sx = kfn(t, [[0, 580], [7.8, 580], [8.6, 400]]);
  const sy = kfn(t, [[0, 575], [5.7, 575], [6.4, 650], [7.8, 650], [8.6, 860]]);
  const zx = kfn(t, [[5.6, 2100], [7.0, 980]]);
  const zp = mix(t, [[5.6, {walk: 1}], [7.0, {walk: 1}], [7.2, {}], [7.7, {h: 110}]]);
  const talk = inSeg(t, [[9.6, 10.5], [10.7, 12.2]]);
  const heart = kfn(t, [[8.4, 0], [8.9, 1]]);
  return (
    <AbsoluteFill>
      <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 45%, #27346E 0%, #0A0E24 75%)'}} />
      <SvgFull>
        <rect y={905} width={1920} height={175} fill="#121838" />
        <rect x={450} y={788} width={1050} height={28} rx={6} fill="#A9743F" stroke={C.ink} strokeWidth={3} />
        <rect x={500} y={816} width={22} height={89} fill="#7A5230" stroke={C.ink} strokeWidth={3} /><rect x={1420} y={816} width={22} height={89} fill="#7A5230" stroke={C.ink} strokeWidth={3} />
        <At x={sx} y={sy} r={kfn(t, [[7.8, 0], [8.6, -30]])}><Sack /></At>
        <Character who="yamin" x={700} y={905} pose={yp} expr={t < 3 ? 'tired' : t < 8.4 ? 'worried' : 'smile'} talk={talk} shake={t < 5.7 ? 1.2 : 0} look={[1, 0.2]} />
        {t > 5.6 && <Character who="zarna" x={zx} y={905} s={0.84} pose={zp} expr="smile" look={[-1, 0.1]} seed={3} />}
        {[0, 1, 2, 3, 4].map((i) => {
          const u = t - (3.0 + i * 0.5);
          if (u < 0 || u > 0.9) return null;
          const x = u < 0.5 ? 80 + (u / 0.5) * 440 : 520 - ((u - 0.5) / 0.4) * 220;
          return <g key={i} opacity={u > 0.5 ? 1 - (u - 0.5) / 0.4 : 1}><At x={x} y={520 + (i % 3) * 60} r={u > 0.5 ? (u - 0.5) * 500 : 0} s={0.8}><QMark /></At></g>;
        })}
        {t > 3.0 && t < 8.7 && <At x={700} y={chestY} s={0.85}><Lock open={kfn(t, [[7.9, 0], [8.4, 1]])} /></At>}
        {t > 8.4 && <At x={700} y={chestY - 6} s={heart * (1 + Math.sin(t * 7) * 0.08)}><Heart /></At>}
        {t > 9.5 && <At x={840} y={560} s={1.4 + Math.sin(t * 6) * 0.12}><Heart /></At>}
      </SvgFull>
      <Overlay>
        <TextCard a={0.2} b={2.9} text="যে মানুষ কষ্ট চেপে রাখে" />
        <TextCard a={3.0} b={5.6} text="তাকে প্রশ্নের পর প্রশ্ন করে খুলে ফেলা যায় না" />
        <TextCard a={5.7} b={9.4} text="পাশে ধৈর্য ধরে বসে থাকলে, সে নিজেই একদিন বোঝাটা নামিয়ে" />
        <TextCard a={9.5} b={12.4} big text="“বসো, একসাথে দেখি।”" />
      </Overlay>
    </AbsoluteFill>
  );
};

const SC = [S1, S2, S3, S4, S5, S6, S7, S8, S9, S10, S11, S12];
const FADE = [false, true, false, true, false, true, true, true, true, true, true, true];

export const Story: React.FC = () => (
  <AbsoluteFill style={{background: '#0b0e1c'}}>
    <Audio src={staticFile('voice.mp3')} />
    {SC.map((Sc, i) => {
      const from = f(B[i]);
      const dur = f(B[i + 1]) - from;
      return (
        <Sequence key={i} from={from} durationInFrames={dur}>
          <SceneCtx.Provider value={{t0: B[i], dur}}>
            <Fade on={FADE[i]}><Sc /></Fade>
          </SceneCtx.Provider>
        </Sequence>
      );
    })}
  </AbsoluteFill>
);
