import React from 'react';
import {Composition} from 'remotion';
import {Story} from './Scenes';
import {FPS, W, H, f, B} from './config';

export const Root: React.FC = () => (
  <Composition id="Story" component={Story} durationInFrames={f(B[B.length - 1])} fps={FPS} width={W} height={H} />
);
