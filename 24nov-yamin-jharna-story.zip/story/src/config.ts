import {createContext, useContext} from 'react';
import {Easing, interpolate, useCurrentFrame} from 'remotion';
import {loadFont} from '@remotion/google-fonts/HindSiliguri';

export const {fontFamily} = loadFont('normal', {weights: ['400', '600', '700'], subsets: ['bengali', 'latin']});

export const FPS = 30, W = 1920, H = 1080;
// সিনের সীমানা (সেকেন্ড) — অডিও/SRT অনুযায়ী। সিন i = [B[i], B[i+1])
export const B = [0, 5.56, 18.0, 21.0, 33.6, 42.4, 45.5, 50.56, 57.64, 66.44, 76.88, 82.02, 94.43];
export const f = (s: number) => Math.round(s * FPS);
export const C = {ink: '#222222', gold: '#FFD54A', green: '#2E9E5B', red: '#D64545', navy: '#0F1530'};

export const SceneCtx = createContext({t0: 0, dur: 1});
export const useT = () => {
  const fr = useCurrentFrame();
  const {t0, dur} = useContext(SceneCtx);
  return {fr, t: fr / FPS, abs: t0 + fr / FPS, dur};
};
export const ramp = (t: number, a: number, b: number) => Math.min(1, Math.max(0, (t - a) / (b - a)));
export const kfn = (t: number, k: [number, number][]) =>
  interpolate(t, k.map((a) => a[0]), k.map((a) => a[1]), {
    extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.inOut(Easing.cubic),
  });
