import React from 'react';
import {AbsoluteFill, spring, useCurrentFrame} from 'remotion';
import {C, FPS, fontFamily, ramp, useT} from './config';

// সময়-ভিত্তিক পপ-আপ (abs সেকেন্ডে a..b)
export const Pop: React.FC<{a: number; b: number; style?: React.CSSProperties; children: React.ReactNode}> = ({a, b, style, children}) => {
  const {abs} = useT();
  if (abs < a || abs > b + 0.3) return null;
  const k = spring({frame: (abs - a) * FPS, fps: FPS, config: {damping: 12, stiffness: 140, mass: 0.6}});
  return <div style={{position: 'absolute', transform: `scale(${k})`, opacity: 1 - ramp(abs, b, b + 0.3), transformOrigin: 'left center', ...style}}>{children}</div>;
};

export const IcoBox: React.FC<{size?: number; children: React.ReactNode}> = ({size = 120, children}) => (
  <svg width={size} height={size} viewBox="-60 -60 120 120" style={{overflow: 'visible'}}>{children}</svg>
);

export const Pill: React.FC<{a: number; b: number; left: number; top: number; text: string; color?: string; icon?: React.ReactNode}> = ({a, b, left, top, text, color = '#FFD54A', icon}) => (
  <Pop a={a} b={b} style={{left, top}}>
    <div style={{display: 'flex', alignItems: 'center', gap: 14, background: color, border: `4px solid ${C.ink}`, borderRadius: 999, padding: '8px 30px 8px 18px', fontFamily, fontWeight: 700, fontSize: 40, color: C.ink, boxShadow: '0 6px 0 rgba(0,0,0,.25)', whiteSpace: 'nowrap'}}>
      {icon && <IcoBox size={52}>{icon}</IcoBox>}{text}
    </div>
  </Pop>
);

export const Bubble: React.FC<{a: number; b: number; left: number; top: number; w: number; tail: number; text: string; size?: number; thought?: boolean}> = ({a, b, left, top, w, tail, text, size = 54, thought}) => (
  <Pop a={a} b={b} style={{left, top, transformOrigin: `${tail}px 100%`}}>
    <div style={{position: 'relative', width: w, background: '#fff', border: `5px solid ${C.ink}`, borderRadius: thought ? 70 : 38, padding: '22px 32px', fontFamily, fontWeight: 700, fontSize: size, lineHeight: 1.35, color: C.ink, textAlign: 'center', boxShadow: '0 8px 0 rgba(0,0,0,.2)'}}>
      {text}
      <div style={{position: 'absolute', left: tail - 24, bottom: -38, width: 0, height: 0, borderLeft: '24px solid transparent', borderRight: '24px solid transparent', borderTop: `40px solid ${C.ink}`}} />
      <div style={{position: 'absolute', left: tail - 18, bottom: -26, width: 0, height: 0, borderLeft: '18px solid transparent', borderRight: '18px solid transparent', borderTop: '32px solid #fff'}} />
    </div>
  </Pop>
);

export const Stamp: React.FC<{a: number; b: number; left: number; top: number; title: string; sub?: string; color?: string; rot?: number; icon?: React.ReactNode}> = ({a, b, left, top, title, sub, color = '#D64545', rot = -3, icon}) => (
  <Pop a={a} b={b} style={{left, top}}>
    <div style={{display: 'flex', alignItems: 'center', gap: 22, transform: `rotate(${rot}deg)`, background: 'rgba(255,255,255,.96)', border: `9px solid ${color}`, borderRadius: 26, padding: '16px 40px', fontFamily, color, boxShadow: '0 10px 0 rgba(0,0,0,.25)'}}>
      {icon && <IcoBox size={90}>{icon}</IcoBox>}
      <div><div style={{fontWeight: 700, fontSize: 70, lineHeight: 1.15, whiteSpace: 'nowrap'}}>{title}</div>{sub && <div style={{fontWeight: 600, fontSize: 38, color: C.ink}}>{sub}</div>}</div>
    </div>
  </Pop>
);

export type Cap = {a: number; b: number; t: string};
export const Captions: React.FC<{items: Cap[]}> = ({items}) => {
  const {abs} = useT();
  const it = items.find((c) => abs >= c.a && abs < c.b);
  if (!it) return null;
  const k = Math.min(1, ((abs - it.a) * FPS) / 8);
  return (
    <div style={{position: 'absolute', left: 0, right: 0, bottom: 56, display: 'flex', justifyContent: 'center', opacity: k, transform: `translateY(${(1 - k) * 26}px)`}}>
      <div style={{fontFamily, fontSize: 62, fontWeight: 600, color: '#fff', background: 'rgba(12,16,34,.7)', padding: '12px 42px', borderRadius: 24, whiteSpace: 'nowrap', textShadow: '0 2px 0 rgba(0,0,0,.5)'}}>
        {it.t.split('**').map((p, i) => (i % 2 ? <span key={i} style={{color: C.gold, fontWeight: 700}}>{p}</span> : <span key={i}>{p}</span>))}
      </div>
    </div>
  );
};

export const Shake: React.FC<{amp: number; children: React.ReactNode}> = ({amp, children}) => {
  const fr = useCurrentFrame();
  return <AbsoluteFill style={{transform: `translate(${Math.sin(fr * 2.9) * amp}px,${Math.cos(fr * 3.7) * amp}px)`}}>{children}</AbsoluteFill>;
};

export const Cam: React.FC<{s: number; ox: number; oy: number; children: React.ReactNode}> = ({s, ox, oy, children}) => (
  <AbsoluteFill style={{transformOrigin: `${ox}px ${oy}px`, transform: `scale(${s})`}}>{children}</AbsoluteFill>
);

export const Fade: React.FC<{on: boolean; children: React.ReactNode}> = ({on, children}) => {
  const fr = useCurrentFrame();
  return <AbsoluteFill style={{opacity: on ? Math.min(1, fr / 7) : 1}}>{children}</AbsoluteFill>;
};
