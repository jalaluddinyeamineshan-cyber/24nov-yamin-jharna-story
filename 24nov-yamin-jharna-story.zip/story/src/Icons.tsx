import React from 'react';
import {useCurrentFrame} from 'remotion';
import {C, fontFamily} from './config';

const st = {stroke: C.ink, strokeWidth: 3, strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const};

// ---------- প্রপস (মূল কোঅর্ডিনেট: কেন্দ্র/নিচ বরাবর) ----------
export const Tin = ({open = 0}: {open?: number}) => (
  <g>
    <ellipse cy={46} rx={96} ry={13} fill="rgba(0,0,0,.22)" />
    {open > 0.3 && (
      <g opacity={Math.min(1, (open - 0.3) * 2)}>
        {[-18, 0, 16].map((r, i) => <rect key={i} x={-26 + i * 4} y={-92 - i * 4} width={52} height={64} rx={4} fill={['#7BC47F', '#6FB86A', '#8ED08F'][i]} stroke={C.ink} strokeWidth={2.5} transform={`rotate(${r} 0 -40)`} />)}
        {[-46, -30, 40, 52].map((x, i) => <circle key={i} cx={x} cy={-54 + (i % 2) * 6} r={12} fill="#F2C94C" stroke={C.ink} strokeWidth={2.5} />)}
      </g>
    )}
    <rect x={-80} y={-50} width={160} height={92} rx={10} fill="#2F6EA8" {...st} />
    <rect x={-80} y={-12} width={160} height={30} fill="#F2C94C" {...st} />
    <text y={10} textAnchor="middle" fontFamily={fontFamily} fontWeight={700} fontSize={24} fill={C.ink}>বিস্কুট</text>
    <g transform={`translate(${open * 74} ${-50 - open * 40}) rotate(${open * 38})`}>
      <rect x={-88} y={-24} width={176} height={26} rx={9} fill="#D5DBE1" {...st} />
      <rect x={-14} y={-34} width={28} height={12} rx={5} fill="#9AA5B1" {...st} />
    </g>
  </g>
);

export const Calculator = () => (
  <g>
    <rect x={-48} y={-62} width={96} height={124} rx={12} fill="#3B3F4A" {...st} />
    <rect x={-36} y={-50} width={72} height={26} rx={4} fill="#B8E0C0" {...st} />
    <text x={32} y={-30} textAnchor="end" fontFamily={fontFamily} fontWeight={700} fontSize={20} fill={C.ink}>০.০০</text>
    {[0, 1, 2, 3].map((r) => [0, 1, 2].map((c) => <rect key={r * 3 + c} x={-34 + c * 24} y={-14 + r * 17} width={19} height={12} rx={3} fill={c === 2 ? '#F2994A' : '#D9DDE3'} stroke={C.ink} strokeWidth={1.5} />))}
  </g>
);

export const Papers = ({n = 4}: {n?: number}) => (
  <g>
    {Array.from({length: n}).map((_, i) => (
      <g key={i} transform={`rotate(${(i - n / 2) * 11} 0 0) translate(${(i % 2) * 6} ${-i * 3})`}>
        <rect x={-42} y={-52} width={84} height={104} fill="#FFFFFF" {...st} />
        {[-32, -20, -8, 4, 16].map((y) => <line key={y} x1={-30} x2={30} y1={y} y2={y} stroke="#9AA5B1" strokeWidth={2.5} />)}
        <text x={-30} y={34} fontFamily={fontFamily} fontSize={16} fontWeight={700} fill="#C0392B">৳ ২৫০০</text>
      </g>
    ))}
  </g>
);

export const Cup = () => {
  const fr = useCurrentFrame();
  return (
    <g>
      <ellipse cy={26} rx={36} ry={8} fill="#F4F4F4" {...st} />
      <path d="M-26 -14 L26 -14 L20 24 Q0 30 -20 24 Z" fill="#FFFFFF" {...st} />
      <ellipse cy={-14} rx={26} ry={7} fill="#B5651D" {...st} />
      <path d="M26 -6 q22 2 4 20" fill="none" {...st} strokeWidth={5} />
      {[0, 1, 2].map((i) => {
        const k = ((fr * 1.1 + i * 22) % 66) / 66;
        return <path key={i} d={`M${-12 + i * 12} ${-24 - k * 50} q6 -10 0 -18`} fill="none" stroke="#fff" strokeWidth={4} strokeLinecap="round" opacity={1 - k} />;
      })}
    </g>
  );
};

export const Glass = () => (
  <g>
    <path d="M-16 -34 L16 -34 L12 22 L-12 22 Z" fill="#CFEFFF" fillOpacity={0.85} {...st} />
    <path d="M-14 -16 L14 -16 L12 22 L-12 22 Z" fill="#7DC6F2" fillOpacity={0.7} />
  </g>
);

export const Kettle = () => (
  <g>
    <path d="M-62 0 L-52 -80 Q0 -100 52 -80 L62 0 Z" fill="#C9D1D8" {...st} />
    <ellipse cy={-86} rx={36} ry={10} fill="#AEB8C1" {...st} />
    <circle cy={-102} r={8} fill="#444" {...st} />
    <path d="M54 -48 Q80 -60 98 -96" fill="none" stroke={C.ink} strokeWidth={16} strokeLinecap="round" />
    <path d="M54 -48 Q80 -60 98 -96" fill="none" stroke="#C9D1D8" strokeWidth={10} strokeLinecap="round" />
    <path d="M-52 -70 Q-104 -60 -58 -14" fill="none" stroke={C.ink} strokeWidth={14} strokeLinecap="round" />
    <path d="M-52 -70 Q-104 -60 -58 -14" fill="none" stroke="#6B4A2B" strokeWidth={8} strokeLinecap="round" />
  </g>
);

export const Steam = ({n = 3}: {n?: number}) => {
  const fr = useCurrentFrame();
  return (
    <g>
      {Array.from({length: n}).map((_, i) => {
        const k = ((fr * 1.2 + i * 30) % 90) / 90;
        return <path key={i} d={`M${-16 + i * 16} ${-k * 90} q10 -14 0 -26 q-10 -14 0 -26`} fill="none" stroke="#fff" strokeWidth={6} strokeLinecap="round" opacity={0.85 * (1 - k)} />;
      })}
    </g>
  );
};

export const Flame = () => {
  const fr = useCurrentFrame();
  return (
    <g>
      {[-30, -15, 0, 15, 30].map((dx, i) => {
        const hh = 16 + Math.abs(Math.sin(fr / 3 + i * 1.7)) * 12;
        return <path key={i} d={`M${dx - 7} 0 Q${dx} ${-hh * 1.9} ${dx + 7} 0 Z`} fill={i % 2 ? '#FFB02E' : '#4FA3FF'} />;
      })}
    </g>
  );
};

export const Notice = () => (
  <g>
    <rect x={-75} y={-95} width={150} height={190} fill="#FFFDF5" {...st} />
    <rect x={-75} y={-95} width={150} height={34} fill="#D64545" {...st} />
    <text y={-70} textAnchor="middle" fontFamily={fontFamily} fontWeight={700} fontSize={26} fill="#fff">নোটিশ</text>
    {[-42, -26, -10, 6, 22, 38].map((y) => <line key={y} x1={-56} x2={y === 38 ? 10 : 56} y1={y} y2={y} stroke="#9AA5B1" strokeWidth={3} />)}
    <circle cx={42} cy={64} r={20} fill="none" stroke="#D64545" strokeWidth={5} />
  </g>
);

export const Sack = () => (
  <g>
    <path d="M-70 60 C-96 -10 -60 -90 -16 -96 L16 -96 C60 -90 96 -10 70 60 Z" fill="#9C7A5B" {...st} />
    <path d="M-20 -96 Q0 -118 20 -96" fill="#7C5E44" {...st} />
    <path d="M-30 -80 Q0 -66 30 -80" fill="none" stroke={C.ink} strokeWidth={5} />
    <text y={20} textAnchor="middle" fontFamily={fontFamily} fontWeight={700} fontSize={46} fill="#fff" stroke={C.ink} strokeWidth={1}>কষ্ট</text>
  </g>
);

// ---------- মোশন গ্রাফিক্স আইকন (-50..50 বক্স) ----------
export const CheckIc = ({c = '#2E9E5B'}: {c?: string}) => (<g><circle r={44} fill={c} {...st} /><path d="M-22 2 L-6 18 L24 -16" fill="none" stroke="#fff" strokeWidth={10} strokeLinecap="round" strokeLinejoin="round" /></g>);
export const ClockIc = ({size = 1, spin = true}: {size?: number; spin?: boolean}) => {
  const fr = useCurrentFrame();
  return (
    <g transform={`scale(${size})`}>
      <circle r={44} fill="#fff" {...st} strokeWidth={5} />
      {[0, 90, 180, 270].map((a) => <line key={a} x1={0} y1={-38} x2={0} y2={-31} stroke={C.ink} strokeWidth={4} transform={`rotate(${a})`} />)}
      <line x1={0} y1={0} x2={0} y2={-26} stroke={C.ink} strokeWidth={6} strokeLinecap="round" transform={`rotate(${spin ? fr * 3 : 60})`} />
      <line x1={0} y1={0} x2={0} y2={-17} stroke={C.red} strokeWidth={7} strokeLinecap="round" transform={`rotate(${spin ? fr * 0.25 : 60})`} />
    </g>
  );
};
export const QMark = ({c = '#FFD54A'}: {c?: string}) => (<g><circle r={44} fill={c} {...st} /><text y={26} textAnchor="middle" fontFamily={fontFamily} fontWeight={700} fontSize={80} fill={C.ink}>?</text></g>);
export const Heart = ({c = '#E85D75'}: {c?: string}) => (<path d="M0 40 C-60 -4 -44 -52 -14 -44 C-6 -42 0 -34 0 -28 C0 -34 6 -42 14 -44 C44 -52 60 -4 0 40 Z" fill={c} {...st} />);
export const Lock = ({open = 0}: {open?: number}) => (
  <g>
    <path d={`M-20 -8 L-20 -26 Q-20 -46 0 -46 Q20 -46 20 -26 L20 ${-8 - open * 16}`} fill="none" stroke={C.ink} strokeWidth={9} strokeLinecap="round" transform={`rotate(${open * 22} 20 -8)`} />
    <rect x={-32} y={-8} width={64} height={52} rx={10} fill="#F2C94C" {...st} />
    <circle cy={16} r={7} fill={C.ink} />
  </g>
);
export const Sun = () => {
  const fr = useCurrentFrame();
  return (
    <g>
      <g transform={`rotate(${fr})`}>{Array.from({length: 10}).map((_, i) => <line key={i} x1={0} y1={-36} x2={0} y2={-52} stroke="#F2994A" strokeWidth={7} strokeLinecap="round" transform={`rotate(${i * 36})`} />)}</g>
      <circle r={30} fill="#FFD54A" {...st} />
    </g>
  );
};
export const Book = () => (<g><path d="M-44 -30 L0 -22 L44 -30 L44 30 L0 38 L-44 30 Z" fill="#5B8DEF" {...st} /><line x1={0} y1={-22} x2={0} y2={38} stroke={C.ink} strokeWidth={3} /><path d="M-30 -14 L-8 -10 M-30 0 L-8 4 M8 -10 L30 -14 M8 4 L30 0" stroke="#fff" strokeWidth={4} strokeLinecap="round" /></g>);
export const Kid = ({c = '#F2994A'}: {c?: string}) => (
  <g>
    <rect x={-26} y={4} width={52} height={44} rx={16} fill={c} {...st} />
    <circle cy={-18} r={26} fill="#C98F63" {...st} />
    <path d="M-26 -24 Q0 -52 26 -24 Q0 -34 -26 -24 Z" fill="#1B1B1B" />
    <circle cx={-9} cy={-16} r={3.5} fill={C.ink} /><circle cx={9} cy={-16} r={3.5} fill={C.ink} />
    <path d="M-8 -5 Q0 2 8 -5" fill="none" stroke={C.ink} strokeWidth={3} strokeLinecap="round" />
  </g>
);
export const Mahajan = () => (
  <g>
    <rect x={-34} y={8} width={68} height={50} rx={18} fill="#8E5A3C" {...st} />
    <circle cy={-16} r={30} fill="#B98259" {...st} />
    <path d="M-30 -26 Q0 -62 30 -26 Z" fill="#F5F0E1" {...st} />
    <path d="M-14 -4 Q0 -12 14 -4 Q0 2 -14 -4 Z" fill="#1c1c1c" />
    <circle cx={-10} cy={-20} r={3.5} fill={C.ink} /><circle cx={10} cy={-20} r={3.5} fill={C.ink} />
  </g>
);
export const Arrow = ({c = '#fff'}: {c?: string}) => (<path d="M-34 0 L20 0 M4 -20 L28 0 L4 20" fill="none" stroke={c} strokeWidth={10} strokeLinecap="round" strokeLinejoin="round" />);
export const Coin = () => (<g><circle r={24} fill="#F2C94C" {...st} /><circle r={15} fill="none" stroke="#C9971A" strokeWidth={3} /><text y={9} textAnchor="middle" fontFamily={fontFamily} fontWeight={700} fontSize={24} fill="#8A6511">৳</text></g>);
export const Note = () => (<g><rect x={-40} y={-22} width={80} height={44} rx={5} fill="#7BC47F" {...st} /><circle r={11} fill="#E9F7EA" {...st} strokeWidth={2} /><text y={6} textAnchor="middle" fontFamily={fontFamily} fontWeight={700} fontSize={16} fill={C.ink}>৳</text></g>);
export const Cross = () => (<g><circle r={44} fill="#D64545" {...st} /><path d="M-18 -18 L18 18 M18 -18 L-18 18" stroke="#fff" strokeWidth={10} strokeLinecap="round" /></g>);
